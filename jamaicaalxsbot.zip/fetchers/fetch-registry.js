/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from KSHK Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

const Tiktok = require('./tiktok.fetch')
const Youtube = require('./youtube.fetch')
const Soundcloud = require('./soundcloud.fetch')
const Spotify = require('./spotify.fetch')
const Instagram = require('./instagram.fetch')
const Twitter = require('./twitter.fetch')
const Facebook = require('./facebook.fetch')
module.exports = {
    Tiktok,
    Youtube,
    Soundcloud,
    Spotify,
    Instagram,
    Twitter,
    Facebook

/* ╭──────────── JAMAICA STORE ────────────╮
 * │ discord.gg/NWXvGhSMA                    │
 * │ © 2026 JAMAICA Store                  │
 * ╰────────────────────────────────────╯ */



/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */


}
