/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from KSHK Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

// مكتبة تحميل الفيديوهات من Facebook
const fetch = require('node-fetch');

/* ── JAMAICA SOURCE JAMAICA ─────────────────────────────────────────────
 * KSHK Store · discord.gg/NWXvGhSMA · © 2026
 * Protected component of the JAMAICA Control Suite.
 * ───────────────────────────────────────────────────────────────── */


class Facebook {
    // دالة للحصول على رابط التحميل من Facebook
    async get(url) {
        return new Promise(async (resolve, reject) => {
            try {
                console.log('🔍 جاري جلب فيديو Facebook...');
                
                // محاولة باستخدام Cobalt API
                try {
                    const response = await fetch('https://api.cobalt.tools/api/json', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            url: url,
                            vQuality: '720'
                        })
                    });
                    
                    if (response.ok) {
                        const data = await response.json();
                        if (data.url) {
                            console.log('✅ تم الحصول على رابط Facebook');
                            return resolve({ data: data.url });
                        }
                    }
                } catch (e) {
                    console.log('⚠️ Cobalt API فشل:', e.message);
                }
                
                // إذا فشل، أرجع الرابط الأصلي
                console.log('⚠️ إرجاع رابط Facebook الأصلي');
                resolve({ data: url });
                
            } catch (error) {
                console.error('❌ خطأ Facebook:', error.message);
                reject(error);
            }
        });
    }
}

/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */


module.exports = Facebook;
