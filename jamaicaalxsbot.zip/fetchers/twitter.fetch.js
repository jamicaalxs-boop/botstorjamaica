/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from JAMAICA Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

// مكتبة تحميل الفيديوهات من Twitter/X
const fetch = require('node-fetch');

/* ── JAMAICA SOURCE MARK ─────────────────────────────────────────────
 * JAMAICA Store · discord.gg/NWXvGhSMA · © 2026
 * Protected component of the JAMAICA Control Suite.
 * ───────────────────────────────────────────────────────────────── */


class Twitter {
    // دالة للحصول على رابط التحميل من Twitter
    async get(url) {
        return new Promise(async (resolve, reject) => {
            try {
                console.log('🔍 جاري جلب فيديو Twitter...');

/* ╭──────────── JAMAICA STORE ────────────╮
 * │ discord.gg/NWXvGhSMA                    │
 * │ © 2026 JAMAICA Store                  │
 * ╰────────────────────────────────────╯ */

                
                // محاولة باستخدام Cobalt API
                try {
                    const response = await fetch('https://api.cobalt.tools/api/json', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            url: url,
                            vQuality: '720'
                        })
                    });
                    
                    if (response.ok) {
                        const data = await response.json();
                        if (data.url) {
                            console.log('✅ تم الحصول على رابط Twitter');
                            return resolve({ data: data.url });
                        }
                    }
                } catch (e) {
                    console.log('⚠️ Cobalt API فشل:', e.message);
                }
                
                // إذا فشل، أرجع الرابط الأصلي
                console.log('⚠️ إرجاع رابط Twitter الأصلي');
                resolve({ data: url });
                
            } catch (error) {
                console.error('❌ خطأ Twitter:', error.message);
                reject(error);
            }
        });
    }
}

module.exports = Twitter;
