/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from KSHK Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

// مكتبة تحميل الصوتيات من SoundCloud
const fs = require('fs');
const path = require('path');

let scdl;
try {
    scdl = require('soundcloud-downloader').default;
} catch (e) {
    console.error('❌ soundcloud-downloader غير متوفر');
}

class Soundcloud {
    // دالة للحصول على ملف الصوت من SoundCloud
    async get(url) {
        return new Promise(async (resolve, reject) => {
            try {
                if (!scdl) {
                    return reject(new Error('مكتبة SoundCloud غير متوفرة'));
                }

/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */


                // استخراج اسم الأغنية من الرابط
                const songName = url.split('/').pop().split('?')[0] || 'audio';
                
                // إنشاء مجلد التحميل إذا لم يكن موجوداً
                const downloadDir = path.join(__dirname, '..', 'media-cache');
                if (!fs.existsSync(downloadDir)) {
                    fs.mkdirSync(downloadDir, { recursive: true });
                    console.log('✅ تم إنشاء مجلد media-cache');
                }
                
                const filePath = path.join(downloadDir, `${songName}.mp3`);

/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */

                
                console.log('🔍 جاري تحميل من SoundCloud...');
                const stream = await scdl.download(url);
                const fileStream = fs.createWriteStream(filePath);

                stream.pipe(fileStream);
                
                fileStream.on('finish', () => {
                    console.log('✅ تم تحميل الصوت:', filePath);
                    resolve(filePath);
                });
                
                fileStream.on('error', (err) => {
                    console.error('❌ خطأ في حفظ الملف:', err);
                    reject(err);
                });
                
            } catch (error) {
                console.error('❌ خطأ في تحميل SoundCloud:', error.message);
                reject(error);
            }
        });
    }
}

module.exports = Soundcloud;
