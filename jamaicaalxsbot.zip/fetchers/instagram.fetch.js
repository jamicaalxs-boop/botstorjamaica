/*
╭──────────────────────────────────────────────────────────────────────╮
│ KSHK CONTROL SUITE                                                  │
│ Copyright © 2026 KSHK Store                                        │
│ Official community: discord.gg/kshk                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from KSHK Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

// مكتبة تحميل الفيديوهات من Instagram
const fetch = require('node-fetch');

// مفتاح RapidAPI
const RAPIDAPI_KEY = 'a4598d0180mshd8782361835e168p1018dbjsnb8a901a16e4b';

class Instagram {
    // دالة للحصول على رابط التحميل من Instagram
    async get(url) {
        return new Promise(async (resolve, reject) => {
            try {
                console.log('🔍 جاري جلب فيديو Instagram...');
                
                // محاولة 1: Instagram Media Downloader
                try {
                    const response = await fetch('https://instagram-media-downloader.p.rapidapi.com/rapid/post.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'X-RapidAPI-Host': 'instagram-media-downloader.p.rapidapi.com',
                            'X-RapidAPI-Key': RAPIDAPI_KEY
                        },
                        body: `url=${encodeURIComponent(url)}`
                    });

/* ╭──────────── KSHK STORE ────────────╮
 * │ discord.gg/kshk                    │
 * │ © 2026 KSHK Store                  │
 * ╰────────────────────────────────────╯ */

                    
                    if (response.ok) {
                        const data = await response.json();
                        console.log('📦 API 1:', JSON.stringify(data).substring(0, 200));
                        
                        // البحث عن رابط الفيديو في الـ response
                        const videoUrl = this.findVideoUrl(data);
                        if (videoUrl) {
                            console.log('✅ تم العثور على رابط');
                            return resolve({ data: videoUrl });
                        }
                    }
                } catch (e) {
                    console.log('⚠️ API 1 فشل:', e.message);
                }
                
                // محاولة 2: Social Media Video Downloader
                try {
                    const response = await fetch(`https://social-media-video-downloader.p.rapidapi.com/smvd/get/all?url=${encodeURIComponent(url)}`, {
                        method: 'GET',
                        headers: {
                            'X-RapidAPI-Host': 'social-media-video-downloader.p.rapidapi.com',
                            'X-RapidAPI-Key': RAPIDAPI_KEY
                        }
                    });

/*
 * [KSHK / CONTROL SUITE]
 * Source ownership: KSHK Store
 * Community: discord.gg/kshk
 * © 2026 KSHK Store — protected source
 */

                    
                    if (response.ok) {
                        const data = await response.json();
                        console.log('📦 API 2:', JSON.stringify(data).substring(0, 200));
                        
                        if (data.links && data.links.length > 0) {
                            const link = data.links.find(l => l.quality === 'hd' || l.quality === 'sd') || data.links[0];
                            if (link && link.link) {
                                console.log('✅ تم العثور على رابط');
                                return resolve({ data: link.link });
                            }
                        }
                    }
                } catch (e) {
                    console.log('⚠️ API 2 فشل:', e.message);
                }
                
                // محاولة 3: إرجاع رابط Instagram الأصلي مع رسالة
                console.log('⚠️ إرجاع رابط Instagram الأصلي');
                resolve({ data: url, isOriginal: true });
                
            } catch (error) {
                console.error('❌ خطأ Instagram:', error.message);
                reject(error);
            }
        });
    }
    
    // دالة للبحث عن رابط الفيديو في البيانات
    findVideoUrl(data) {
        if (!data) return null;
        
        // البحث في مختلف الأماكن المحتملة
        if (typeof data === 'string' && data.startsWith('http')) return data;
        if (data.video) return data.video;
        if (data.url) return data.url;
        if (data.download_url) return data.download_url;
        if (data.media) return typeof data.media === 'string' ? data.media : data.media.url;
        if (data.video_url) return data.video_url;
        if (Array.isArray(data) && data.length > 0) {
            return data[0].url || data[0].video || data[0];
        }
        if (data.data) return this.findVideoUrl(data.data);
        
        return null;
    }
}

module.exports = Instagram;
