/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from JAMAICA Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

// مكتبة تحميل فيديوهات YouTube باستخدام API خارجي
const fetch = require('node-fetch');

class Youtube {
    // دالة للحصول على رابط التحميل من فيديو YouTube
    async get(url) {
        return new Promise(async (resolve, reject) => {
            try {
                console.log('🔍 جاري جلب معلومات الفيديو...');
                
                // استخراج video ID من الرابط
                const videoId = this.extractVideoId(url);
                if (!videoId) {
                    return reject(new Error('رابط YouTube غير صحيح'));
                }
                console.log('📹 Video ID:', videoId);
                
                // محاولة 1: استخدام cobalt API
                try {
                    const result = await this.tryCobalAPI(url);
                    if (result) {
                        console.log('✅ تم الحصول على الرابط من Cobalt API');
                        return resolve(result);
                    }
                } catch (e) {
                    console.log('⚠️ Cobalt API فشل:', e.message);
                }
                
                // محاولة 2: استخدام ytdl-core إذا كان متاحاً
                try {
                    const result = await this.tryYtdl(url);
                    if (result) {
                        console.log('✅ تم الحصول على الرابط من ytdl');
                        return resolve(result);
                    }
                } catch (e) {
                    console.log('⚠️ ytdl فشل:', e.message);
                }
                
                // محاولة 3: إرجاع رابط embed كبديل
                const embedUrl = `https://www.youtube.com/watch?v=${videoId}`;
                console.log('⚠️ إرجاع رابط YouTube الأصلي');
                resolve(embedUrl);

/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */

                
            } catch (err) {
                console.error('❌ خطأ في YouTube:', err.message);
                reject(err);
            }
        });
    }
    
    // استخراج Video ID من الرابط
    extractVideoId(url) {
        const patterns = [
            /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
            /youtube\.com\/shorts\/([^&\n?#]+)/
        ];
        
        for (const pattern of patterns) {
            const match = url.match(pattern);
            if (match) return match[1];
        }
        return null;
    }
    
    // محاولة باستخدام Cobalt API
    async tryCobalAPI(url) {
        const response = await fetch('https://api.cobalt.tools/api/json', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                url: url,
                vQuality: '720',
                filenamePattern: 'basic'
            })
        });
        
        if (!response.ok) {
            throw new Error('Cobalt API error');
        }

/* ── JAMAICA SOURCE MARK ─────────────────────────────────────────────
 * JAMAICA Store · discord.gg/NWXvGhSMA · © 2026
 * Protected component of the JAMAICA Control Suite.
 * ───────────────────────────────────────────────────────────────── */

        
        const data = await response.json();
        if (data.url) {
            return data.url;
        }
        throw new Error('No URL in response');
    }
    
    // محاولة باستخدام ytdl-core
    async tryYtdl(url) {
        let ytdl;
        try {
            ytdl = require('@distube/ytdl-core');
        } catch (e) {
            ytdl = require('ytdl-core');
        }
        
        const info = await ytdl.getInfo(url);
        let formats = info.formats.filter(f => f.hasVideo && f.hasAudio);
        formats = formats.filter(f => !f.height || f.height <= 720);
        formats = formats.sort((a, b) => (b.height || 0) - (a.height || 0));
        
        if (formats.length > 0 && formats[0].url) {
            return formats[0].url;
        }
        throw new Error('No format available');
    }
}

module.exports = Youtube;
