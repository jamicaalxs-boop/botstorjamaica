/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from JAMAICA Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

const turl = require('turl');
const fs = require('fs'); // وحدة نظام الملفات

/* ── JAMAICA SOURCE MARK ─────────────────────────────────────────────
 * JAMAICA Store · discord.gg/NWXvGhSMA · © 2026
 * Protected component of the JAMAICA Control Suite.
 * ───────────────────────────────────────────────────────────────── */


class Spotify {
    async get(url) {
        return new Promise(async (resolve, reject) => {
            try {
                const response = await fetch(`https://media.hlse.xyz/download?url=${url}`);
                const data = await response.json();

                if (data.success === false) {
                    message.reply(`تأكد من رابط المنصة بدقة.`);
                }
                resolve(data)
            } catch (error) {
                console.error(error);
                return Promise.reject("حدث خطأ أثناء محاولة تنفيذ طلبك. الرجاء المحاولة لاحقًا.");
            }
        })
    }
}

// JAMAICA Store • Protected Source • discord.gg/NWXvGhSMA • © 2026


module.exports = Spotify;
