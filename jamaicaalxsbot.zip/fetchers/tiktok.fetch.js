/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from JAMAICA Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

const axios = require('axios')
const cheerio = require('cheerio')
const qs = require('qs')

/* ── JAMAICA SOURCE MARK ─────────────────────────────────────────────
 * JAMAICA Store · discord.gg/NWXvGhSMA · © 2026
 * Protected component of the JAMAICA Control Suite.
 * ───────────────────────────────────────────────────────────────── */


class TickTok {
    get(url) {
        return new Promise((resolve, reject) => {
            axios.get('https://ttdownloader.com/')
                .then((data) => {
                    const $ = cheerio.load(data.data)
                    const cookie = data.headers['set-cookie'].join('')
                    const dataPost = {
                        url: url,
                        format: '',
                        token: $('#token').attr('value')
                    }

/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */


                    axios({
                        method: 'POST',
                        url: 'https://ttdownloader.com/search/',
                        headers: {
                            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            origin: 'https://ttdownloader.com',
                            referer: 'https://ttdownloader.com/',
                            cookie
                        },
                        data: qs.stringify(dataPost)
                    }).then(({ data }) => {
                        const result = this.getObject(data)
                        resolve(result);
                    })
                        .catch(e => {
                            reject({ status: false, message: 'error fetch data', e: e.message })
                        })
                })
                .catch(e => {
                    reject({ status: false, message: 'error fetch data', e: e.message })
                })
        })
    }

    getObject(data) {
        const $ = cheerio.load(data)
        return {
            media: {
                url: $('#results-list > div:nth-child(2) > div.download > a')?.attr('href'),
                type: 'mp4'
            }
        }
    }
}

module.exports = TickTok
