/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from KSHK Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

const Discord = require('discord.js');
const fs = require('fs');
const fetch = require('node-fetch');
"use strict";
module.exports = async (client, interaction) => {
    // التحقق مما إذا كان التفاعل هو إرسال نموذج وإذا كان معرف النموذج هو `Downolad`
    if (interaction.isModalSubmit() && interaction.customId === `Downolad`) {
        // الحصول على عنوان URL المدخل
        const Url = interaction.fields.getTextInputValue('Downolads');
        console.log("عنوان URL للتنزيل:", Url);

        // تأجيل الرد مؤقتًا
        await interaction.deferReply({ ephemeral: true });

        // استخراج الروابط من النص
        let urls = Url.match(/\bhttps:\/\/\S+/gi);
        if (urls && urls.length > 0) {
            urls.forEach(url => {
                let type = getMediaType(url);
                console.log("نوع وسائط مكتشف:", type);
                switch (type) {
                    case "Tiktok":
                        client.tiktok.get(url).then((data) => {
                            sendTiktok(interaction, data);
                        }).catch(err => {
                            interaction.followUp(`**لم أتمكن من العثور عليه ❌ .**`);
                            console.error("خطأ أثناء جلب بيانات Tiktok:", err);
                        });
                        break;
                    case "Youtube":
                        client.youtube.get(url).then((data) => {
                            sendYoutube(interaction, data);
                        }).catch(err => {
                            interaction.followUp(`**لم أتمكن من العثور عليه ❌ .**`);
                            console.error("خطأ أثناء جلب بيانات Youtube:", err);
                        });
                        break;
                    case "Soundcloud":
                        client.soundcloud.get(url).then((data) => {
                            sendSoundcloud(interaction, data);
                        }).catch(err => {
                            interaction.followUp(`**لم أتمكن من العثور عليه ❌ .**`);
                            console.error("خطأ أثناء جلب بيانات Soundcloud:", err);
                        })
                        break;
                    case "Spotify":
                        client.spotify.get(url).then((data) => {
                            sendSpotify(interaction, data);
                        }).catch(err => {
                            interaction.followUp(`**لم أتمكن من العثور عليه ❌ .**`);
                            console.error("خطأ أثناء جلب بيانات Spotify:", err);
                        })
                        break;

                    case "Instagram":
                        client.instagram.get(url).then((data) => {
                            sendInstagram(interaction, data);
                        }).catch(err => {
                            interaction.followUp(`**لم أتمكن من العثور عليه ❌ .**`);
                            console.error("خطأ أثناء جلب بيانات Instagram:", err);
                        })
                        break;
                    case "Twitter":
                        client.twitter.get(url).then((data) => {
                            sendTwitter(interaction, data);
                        }).catch(err => {
                            interaction.followUp(`**لم أتمكن من العثور عليه ❌ .**`);
                            console.error("خطأ أثناء جلب بيانات Twitter:", err);
                        })
                        break;

/*
 * [KSHK / CONTROL SUITE]
 * Source ownership: KSHK Store
 * Community: discord.gg/kshk
 * © 2026 KSHK Store — protected source
 */


                    case "Facebook":
                        client.facebook.get(url).then((data) => {
                            sendFacebook(interaction, data);
                        }).catch(err => {
                            interaction.followUp(`**لم أتمكن من العثور عليه ❌ .**`);
                            console.error("خطأ أثناء جلب بيانات Facebook:", err);
                        })
                        break;

                    default:
                }
            });
        }
    }
};


/* ╭──────────── JAMAICA STORE ────────────╮
 * │ discord.gg/NWXvGhSMA                    │
 * │ © 2026 JAMAICA Store                  │
 * ╰────────────────────────────────────╯ */



// دالة للحصول على نوع وسائط معين من رابط
function getMediaType(media) {
    if (media.includes('www.tiktok.com') || media.includes('vm.tiktok.com') || media.includes('tiktok.com')) {
        console.log("تم اكتشاف رابط Tiktok:", media);
        return 'Tiktok';
    } else if (media.includes('www.youtube.com') || media.includes('youtu.be') || media.includes('youtube.com') || media.includes('youtu.be')) {
        console.log("تم اكتشاف رابط YouTube:", media);
        return 'Youtube';
    } else if (media.includes('soundcloud.com') || media.includes('www.soundcloud.com')) {
        console.log("تم اكتشاف رابط Soundcloud:", media);
        return 'Soundcloud';
    } else if (media.includes('www.spotify.com') || media.includes('open.spotify.com') || media.includes('spotify.com') || media.includes('https://open.spotify.com')) {
        console.log("تم اكتشاف رابط Spotify:", media);
        return 'Spotify';
    } else if (media.includes('www.instagram.com') || media.includes('instagram.com')) {
        console.log("تم اكتشاف رابط Instagram:", media);
        return 'Instagram';
    } else if (media.includes('www.facebook.com') || media.includes('facebook.com') || media.includes('fb.watch') || media.includes('fb.me') || media.includes('fb.com') || media.includes('fb.watch')) {
        console.log("تم اكتشاف رابط Facebook:", media);
        return 'Facebook';

    } else if (media.includes('www.twitter.com') || media.includes('twitter.com') || media.includes('t.co') || media.includes('twimg.com') || media.includes('x.com')) {
        console.log("تم اكتشاف رابط Twitter:", media);
        return 'Twitter';

    }
}


// دوال لإرسال محتوى الوسائط المختلفة
function sendFacebook(interaction, data) {
    interaction.followUp({
        files: [{ attachment: data.data, name: `twitter.mp4` }],
        ephemeral: true
    }).catch(err => {
        console.error("خطأ أثناء إرسال فيديو Facebook:", err);
        interaction.reply("فشل في إرسال الفيديو من Facebook. يرجى المحاولة مرة أخرى لاحقًا.");
    });
}


function sendTwitter(interaction, data) {
    interaction.followUp({
        files: [{ attachment: data.data, name: `twitter.mp4` }],
        ephemeral: true
    }).catch(err => {
        console.error("خطأ أثناء إرسال فيديو Twitter:", err);
        interaction.followUp({ content: "**❌ فشل في إرسال الفيديو من Twitter.**", ephemeral: true }).catch(() => {});
    });
}

// دالة إرسال فيديو Instagram
async function sendInstagram(interaction, data) {
    try {
        // التحقق من نوع البيانات
        if (data && data.data && typeof data.data === 'string' && data.data.startsWith('http')) {
            // التحقق إذا كان الرابط الأصلي
            if (data.isOriginal) {
                await interaction.followUp({
                    content: `**📸 رابط Instagram:**\n${data.data}\n\n**💡 للتحميل استخدم:**\n• https://snapinsta.app\n• https://igram.io`,
                    ephemeral: true
                });
            } else {
                // إرسال رابط التحميل
                await interaction.followUp({
                    content: `**📸 رابط تحميل Instagram:**\n${data.data}`,
                    ephemeral: true
                });
            }
        } else if (data && Buffer.isBuffer(data.data)) {
            await interaction.followUp({
                files: [{ attachment: data.data, name: 'insta.mp4' }],
                ephemeral: true
            });
        } else {
            await interaction.followUp({
                content: '**❌ فشل في الحصول على رابط التحميل - جرب رابط آخر**',
                ephemeral: true
            });
        }
    } catch (err) {
        console.error("خطأ أثناء إرسال فيديو Instagram:", err);
        await interaction.followUp({ 
            content: "**❌ فشل في إرسال الفيديو من Instagram.**", 
            ephemeral: true 
        }).catch(() => {});
    }
}

function sendTiktok(interaction, data) {
    interaction.followUp({
        files: [{ attachment: data.media.url, name: `tiktok.mp4` }],
        ephemeral: true
    }).catch(err => {
        console.error("خطأ أثناء إرسال فيديو Tiktok:", err);
        interaction.reply("فشل في إرسال الفيديو من Tiktok. يرجى المحاولة مرة أخرى لاحقًا.");
    });
}

function sendSpotify(interaction, data) {
    interaction.followUp({
        files: [{ attachment: data.url, name: `Spotify.mp3` }],
    }).catch(err => {
        console.error("خطأ أثناء إرسال صوت Spotify:", err);
        interaction.reply("فشل في إرسال الصوت من Spotify. يرجى المحاولة مرة أخرى لاحقًا.");
    });
}

function sendSoundcloud(interaction, data) {

    interaction.followUp({
        files: [{ attachment: data, name: `soundcloud.mp3` }],
        ephemeral: true
    }).catch(err => {
        console.error("خطأ أثناء إرسال صوت Soundcloud:", err);
        interaction.reply("فشل في إرسال الصوت من Soundcloud. يرجى المحاولة مرة أخرى لاحقًا.");
    });
}

// دالة إرسال فيديو YouTube - إرسال رابط التحميل المباشر
async function sendYoutube(interaction, data) {
    try {
        // إرسال رابط التحميل أو رابط YouTube
        if (typeof data === 'string' && data.length > 0) {
            // التحقق إذا كان رابط تحميل مباشر أو رابط YouTube عادي
            if (data.includes('googlevideo.com') || data.includes('videoplayback')) {
                await interaction.followUp({
                    content: `**📹 رابط تحميل الفيديو (صالح لفترة محدودة):**\n${data}`,
                    ephemeral: true
                });
            } else {
                // رابط YouTube عادي - أرسله مع رسالة توضيحية
                await interaction.followUp({
                    content: `**📹 رابط الفيديو:**\n${data}\n\n**💡 للتحميل استخدم:**\n• https://y2mate.com\n• https://savefrom.net`,
                    ephemeral: true
                });
            }
        } else if (Buffer.isBuffer(data)) {
            // إذا كان Buffer
            await interaction.followUp({
                files: [{ attachment: data, name: 'youtube.mp4' }],
                ephemeral: true
            });
        } else {
            await interaction.followUp({
                content: '**❌ فشل في الحصول على رابط التحميل**',
                ephemeral: true
            });
        }
    } catch (err) {
        console.error("خطأ أثناء إرسال فيديو Youtube:", err);
        await interaction.followUp({
            content: '**❌ فشل في إرسال الفيديو. يرجى المحاولة مرة أخرى.**',
            ephemeral: true
        }).catch(() => {});
    }
}
