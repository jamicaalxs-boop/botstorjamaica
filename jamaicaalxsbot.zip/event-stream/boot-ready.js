/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 KSHK Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from KSHK Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

"use strict";

const config = require("../runtime.settings");
module.exports = async (client) => {
  console.log(`${client.user.tag} is ready`);
  console.log(`${client.generateInvite({ scopes: ['bot', 'applications.commands'], permissions: "ADMINISTRATOR" })}`);
};
