/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from JAMAICA Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

// ملف إعدادات البوت الرئيسية

module.exports = {
    // ========== إعدادات البوت الأساسية ==========
    
    // بادئة الأوامر (مثال: +control)
    prefix: "+",

    // توكن البوت الرئيسي من Discord Developer Portal
    token: "",

    // توكن السيلف بوت (حساب Discord عادي)
    users: "",

    // قائمة المالكين المخولين بالصلاحيات الإدارية
    owners: [""],

    // ========== إعدادات API الخارجية ==========

    // مفتاح OpenAI API - للذكاء الاصطناعي (إنشاء صور فقط)
    // احصل على مفتاح من: https://platform.openai.com/api-keys
    openaiKey: "sk-ضع_مفتاح_OpenAI_هنا",

    // مفتاح RapidAPI - لتحميل الفيديوهات من المنصات
    // احصل على مفتاح من: https://rapidapi.com
    rapidApiKey: "a4598d0180mshd8782361835e168p1018dbjsnb8a901a16e4b",

    // مفتاح Remove.bg API - لحذف خلفية الصور
    // احصل على مفتاح من: https://www.remove.bg/api
    removeBgKey: "BhCew7kBAPtyrfLL8ekin8Lg",

    // ========== إعدادات نظام AI (OpenRouter) ==========
    
    // مفاتيح API لكل سيرفر (OpenRouter)
    // احصل على مفتاح من: https://openrouter.ai/keys
    aiApiKeys: {
        "1488596139669192707": "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",
        "1488596139669192707": "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"
    },

/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */


    // آيدي الكاتيجوري الذي تُفتح فيه تكتات AI
    aiTicketCategory: "",

/*
 * [JAMAICA / CONTROL SUITE]
 * Source ownership: JAMAICA Store
 * Community: discord.gg/NWXvGhSMA
 * © 2026 JAMAICA Store — protected source
 */


    // دالة لطباعة الرسائل في الكونسول
    log: function (message) {
        console.log(message);
    }
};
