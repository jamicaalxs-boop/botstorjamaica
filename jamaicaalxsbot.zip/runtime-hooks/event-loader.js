/*
╭──────────────────────────────────────────────────────────────────────╮
│ JAMAICA CONTROL SUITE                                                  │
│ Copyright © 2026 JAMAICA Store                                        │
│ Official community: discord.gg/NWXvGhSMA                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from JAMAICA Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

"use strict";
const fs = require("fs");
const path = require("path");
module.exports = async (client) => {
  let EventsDir = path.join(__dirname, "..", "event-stream");
  fs.readdir(EventsDir, (err, files) => {
    if (err) console.log(err);
    else
      files.forEach((file) => {
        const event = require(EventsDir + "/" + file);
        client.on(file.split(".")[0], event.bind(null, client));
        console.log(`➼ Event Loaded : ${file.split(".")[0]}`);
      });
  });
};
