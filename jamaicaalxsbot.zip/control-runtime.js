/*
╭──────────────────────────────────────────────────────────────────────╮
│ KSHK CONTROL SUITE                                                  │
│ Copyright © 2026 KSHK Store                                        │
│ Official community: discord.gg/kshk                                 │
│                                                                     │
│ Protected source — redistribution or removal of this notice is     │
│ not permitted without authorization from KSHK Store.                │
╰──────────────────────────────────────────────────────────────────────╯
*/

// استيراد مكتبة Discord.js للبوت العادي
const Discord = require("discord.js");

// استيراد مكتبة السيلف بوت
const Self = require('discord.js-selfbot-v13');

// ====== AI SYSTEM ======
const fs = require("fs");
const path = require("path");
// قراءة مفاتيح API من إعدادات التشغيل
function getGuildAPIKey(guildId) {
    return config.aiApiKeys[guildId] || null;
}

// إنشاء كلاينت السيلف بوت مع الإعدادات
const clients = new Self.Client({
    checkUpdate: false
});

// دالة للبحث عن المستخدم في جميع السيرفرات والحصول على بيانات البروفايل والشارات
async function findUserProfileInAllGuilds(userId) {
    if (!clients.user) {
        return { error: 'السيلف بوت غير متصل' };
    }
    
    console.log(`البحث عن المستخدم ${userId}`);
    console.log(`السيلف بوت في ${clients.guilds.cache.size} سيرفر`);
    
    // البحث في كل السيرفرات للسيلف بوت فقط (عشان getProfile)
    for (const guild of clients.guilds.cache.values()) {
        console.log(`🔍 البحث في سيرفر: ${guild.name} (${guild.id})`);
        try {
            const member = await guild.members.fetch(userId);
            if (member) {
                console.log(`تم العثور على المستخدم في ${guild.name}`);
                
                // جرب طرق مختلفة للحصول على الـ profile
                let profile = null;
                try {
                    // الطريقة الصحيحة في discord.js-selfbot-v13
                    const user = await clients.users.fetch(userId);
                    profile = await user.getProfile();
                    console.log(`تم الحصول على الـ profile بـ user.getProfile`);
                } catch (error1) {
                    console.log(`user.getProfile فشل: ${error1.message}`);
                    try {
                        // طريقة تانية
                        profile = await member.user.getProfile();
                        console.log(`تم الحصول على الـ profile بـ member.user.getProfile`);
                    } catch (error2) {
                        console.log(`member.user.getProfile فشل: ${error2.message}`);
                        try {
                            // طريقة تالتة - استخدام REST API
                            const response = await clients.api.users(userId).profile.get();
                            profile = { badges: response.badges || [] };
                            console.log(`تم الحصول على الـ profile بـ REST API`);
                        } catch (error3) {
                            console.log(`REST API فشل: ${error3.message}`);
                            // استخدم member عادي بدون profile
                            console.log(`استخدام fallback بدون badges`);
                            return { member, guild, profile: { badges: [] } };
                        }
                    }
                }
                
                return { member, guild, profile };
            }
        } catch (error) {
            console.log(`خطأ في ${guild.name}: ${error.message}`);
            continue;
        }
    }
    
    return { error: `مش قادر ألاقي الشخص ده في أي سيرفر مشترك مع السيلف بوت (تم البحث في ${clients.guilds.cache.size} سيرفر)` };
}

// دالة للبحث عن المستخدم في جميع السيرفرات بدون الحاجة للبروفايل
async function findUserInAllGuilds(userId) {
    // البحث في سيرفرات السيلف بوت الأول
    if (clients.user) {
        for (const guild of clients.guilds.cache.values()) {
            try {
                const member = await guild.members.fetch(userId);
                if (member) {
                    return { member, guild, isSelfBot: true };
                }
            } catch (error) {
                continue;
            }
        }
    }
    
    // البحث في سيرفرات البوت العادي
    for (const guild of client.guilds.cache.values()) {
        try {
            const member = guild.members.cache.get(userId);
            if (member) {
                return { member, guild, isSelfBot: false };
            }
        } catch (error) {
            continue;
        }
    }
    
    return { error: 'مش قادر ألاقي الشخص ده في أي سيرفر مشترك' };
}

// دالة لتنظيف روابط الصور واستخراج الرابط الأصلي
function cleanImageUrl(url) {
    if (!url) return url;
    
    let finalUrl = url;
    
    // استخراج الرابط الأصلي من روابط Discord الخارجية (images-ext)
    if (url.includes('images-ext') && url.includes('/https/')) {
        const match = url.match(/\/https\/(.+?)(\?|$)/);
        if (match) {
            finalUrl = 'https://' + match[1];
        }
    } 
    // تحويل روابط Discord العادية من WebP لـ PNG
    else if (url.includes('cdn.discordapp.com') || url.includes('media.discordapp.net')) {
        if (url.includes('format=webp')) {
            finalUrl = url.replace('format=webp', 'format=png');
        }
        if (!finalUrl.includes('format=')) {
            finalUrl = finalUrl.split('?')[0] + '?format=png&size=1024';
        }
    }
    
    return finalUrl;
}

// دوال مساعدة للتصميم المحسّن
function drawRoundedRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
}

function drawGradientBackground(ctx, width, height, color1 = '#1e2124', color2 = '#282b30') {
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, color1);
    gradient.addColorStop(1, color2);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
}

function drawShadow(ctx, blur = 10, color = 'rgba(0, 0, 0, 0.3)') {
    ctx.shadowColor = color;
    ctx.shadowBlur = blur;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 2;
}

function clearShadow(ctx) {
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
}

async function drawCircularAvatar(ctx, avatarUrl, x, y, radius) {
    try {
        const avatar = await loadImage(cleanImageUrl(avatarUrl));
        ctx.save();
        
        // رسم ظل للأفتار
        drawShadow(ctx, 8, 'rgba(0, 0, 0, 0.4)');
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = '#5865f2';
        ctx.fill();
        
        // رسم الأفتار
        clearShadow(ctx);
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar, x - radius, y - radius, radius * 2, radius * 2);
        ctx.restore();
        
        // إطار للأفتار
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        return true;
    } catch (e) {
        // رسم دائرة افتراضية
        ctx.save();
        drawShadow(ctx, 8, 'rgba(0, 0, 0, 0.4)');
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = '#5865f2';
        ctx.fill();
        clearShadow(ctx);
        ctx.restore();
        return false;
    }
}

// دالة مساعدة لتحميل الصور من URL
async function loadImageFromUrl(url) {
    try {
        console.log('جاري تحميل الصورة من:', url);

        const finalUrl = cleanImageUrl(url);
        console.log('الرابط النهائي:', finalUrl);

        const response = await fetch(finalUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        if (!response.ok) {
            console.log(`فشل تحميل الصورة: ${response.status}`);
            throw new Error('فشل في تحميل الصورة - تأكد من صحة الرابط');
        }

        const buffer = await response.buffer();

        if (!buffer || buffer.length === 0) {
            throw new Error('الصورة فارغة');
        }

        console.log('حجم الصورة:', buffer.length, 'bytes');

        return await loadImage(buffer);
    } catch (err) {
        console.log('خطأ:', err.message);
        throw new Error('فشل في تحميل الصورة. تأكد من:\n• الرابط صحيح ومباشر\n• الصورة بصيغة PNG أو JPG');
    }
}

// دالة لإنشاء الصور مع إضافة نص وصورة دائرية (أفتار)
async function generateImage(basePath, options = {}) {
    try {
        const Image = await canvase.loadImage(basePath);
        const canvas = new canvase.Canvas(Image.width, Image.height)
            .printImage(Image, 0, 0, Image.width, Image.height);
        
        if (options.text) {
            canvas
                .setColor('#ffffff')
                .setTextFont(options.font || 'italic bold 15px Arial')
                .setTextAlign('center')
                .printText(options.text, options.x || 260, options.y || 205);
        }
        
        if (options.avatar) {
            canvas.printCircularImage(await canvase.loadImage(options.avatar), options.ax || 250, options.ay || 230, options.r || 50);
        }
        
        return canvas.toBuffer();
    } catch (error) {
        console.error('خطأ في إنشاء الصورة:', error);
        throw error;
    }
}

// استيراد مكتبات التحميل من منصات التواصل الاجتماعي
const {
    Tiktok,
    Youtube,
    Spotify,
    Soundcloud,
    Instagram,
    Twitter,
    Facebook
} = require('./fetchers/fetch-registry');

// مكتبة إنشاء صور GIF متحركة
const GIFEncoder = require('gifencoder');
const GIFEncoder2 = require('gif-encoder-2');
const gifken = require('gifken');
const axios = require('axios');
const sharpApng = require('sharp-apng');

// ====== EFFECTS SYSTEM ======
const effectOptions = require('./visual.effects.json');

// دالة تحميل إطارات APNG
async function downloadAPNG(url) {
    const response = await axios.get(url, { responseType: "arraybuffer" });
    const data = Buffer.from(response.data);
    const frames = await sharpApng.framesFromApng(data);
    return frames;
}

// دالة إنشاء GIF مع التأثير
const createEffectGif = async (imageUrl, effectID) => {
    try {
        const img = await loadImage(imageUrl);
        const canvas = createCanvas(img.width, img.height);
        const ctx = canvas.getContext("2d");

        const encoder = new GIFEncoder2(img.width, img.height, "octree", true);
        encoder.start();
        encoder.setRepeat(0);
        encoder.setDelay(100);

        const effectUrl = effectOptions.find((effect) => effect.id === effectID);
        if (!effectUrl) {
            throw new Error(`التأثير بالمعرف ${effectID} غير موجود.`);
        }

        const frames = await downloadAPNG(effectUrl.url);
        console.log(`عدد الإطارات: ${frames.length}`);

        for (const frameFile of frames) {
            const buffer = await frameFile.toFormat("png").toBuffer();
            const frameImage = await loadImage(buffer);

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            ctx.drawImage(frameImage, 0, 0, canvas.width, canvas.height);

            encoder.addFrame(ctx);
        }

        encoder.finish();
        const buffer = encoder.out.getData();

        const reversedBuffer = await gifken.reverse(buffer);
        return Buffer.from(reversedBuffer);
    } catch (error) {
        console.error("خطأ في إنشاء الصورة المتحركة:", error);
        return null;
    }
};

// دالة إنشاء قوائم اختيار التأثيرات
const createEffectSelectMenus = () => {
    const groupedEffects = effectOptions.reduce((acc, effect) => {
        acc[effect.category] = (acc[effect.category] || []).concat(effect);
        return acc;
    }, {});

    const menus = [];

    Object.entries(groupedEffects).forEach(([category, effects]) => {
        let categoryName = category;
        if (category === 'decorations') {
            categoryName = 'زخارف';
        } else if (category === 'flags') {
            categoryName = 'اعلام';
        }
        
        const limitedEffects = effects.slice(0, 25);
        
        const menu = new Discord.MessageActionRow().addComponents(
            new Discord.MessageSelectMenu()
                .setCustomId(`effect_select_${category}`)
                .setPlaceholder(`اختر من ${categoryName}`)
                .addOptions(
                    limitedEffects.map((effect) => {
                        return {
                            label: `${effect.label || effect.name || effect.id}`.slice(0, 99),
                            value: `${effect.id}`
                        };
                    })
                )
        );
        menus.push(menu);
    });

    return menus;
};

// استيراد مكونات Discord.js للرسائل التفاعلية
const { MessageActionRow, MessageSelectMenu, MessageEmbed, MessageButton, Modal, TextInputComponent } = require('discord.js');

// استيراد مكتبة OpenAI للذكاء الاصطناعي
const { OpenAI } = require("openai");

// مكتبة الترجمة من Bing
const { translate } = require("bing-translate-api");

// مكتبة لإنشاء صور Canvas
const canvafy = require("canvafy");

// مكتبة قاعدة البيانات
const Data = require("pro.db");
const Pro = require("pro.db")

// استيراد ملف الإعدادات
const config = require("./runtime.settings");

// إعداد OpenAI مع مفتاح API من ملف الإعدادات
const openai = new OpenAI({
    apiKey: config.openaiKey
})

// نظام الكولداون للنشر (30 دقيقة بين كل نشر) - محفوظ في قاعدة البيانات
const PUBLISH_COOLDOWN_TIME = 30 * 60 * 1000; // 30 دقيقة بالميلي ثانية

// دالة للحصول على وقت آخر نشر للمستخدم من قاعدة البيانات
function getPublishCooldown(userId) {
    return Pro.get(`cooldown_${userId}`) || 0;
}

// دالة لتعيين وقت النشر للمستخدم في قاعدة البيانات
function setPublishCooldown(userId) {
    Pro.set(`cooldown_${userId}`, Date.now());
}

// دالة للتحقق من الكولداون وإرجاع الوقت المتبقي
function checkCooldown(userId) {
    const lastPublish = getPublishCooldown(userId);
    const now = Date.now();
    if (lastPublish) {
        const timeLeft = PUBLISH_COOLDOWN_TIME - (now - lastPublish);
        if (timeLeft > 0) {
            return timeLeft; // إرجاع الوقت المتبقي
        }
    }
    return 0; // لا يوجد كولداون
}

// دالة للتحقق من صحة رابط دعوة Discord
function isValidDiscordInvite(link) {
    const discordInviteRegex = /^(https?:\/\/)?(www\.)?(discord\.gg|discordapp\.com\/invite|discord\.com\/invite)\/[a-zA-Z0-9]+$/;
    return discordInviteRegex.test(link);
}

// دالة لتنسيق رابط الدعوة وإضافة https إذا لم يكن موجوداً
function formatDiscordInvite(link) {
    if (!link.startsWith('http://') && !link.startsWith('https://')) {
        return 'https://' + link;
    }
    return link;
}

// دالة لتنسيق وقت الكولداون المتبقي
function formatCooldownTime(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
// إنشاء كلاينت البوت الرئيسي مع الإعدادات والصلاحيات
const client = new Discord.Client({
    intents: [
        "GUILDS",              // صلاحية الوصول للسيرفرات
        "GUILD_MESSAGES",      // صلاحية قراءة الرسائل
        "GUILD_MEMBERS",       // صلاحية الوصول للأعضاء
        "GUILD_MESSAGE_REACTIONS", // صلاحية التفاعلات
        "DIRECT_MESSAGES",     // صلاحية الرسائل الخاصة
        "GUILD_VOICE_STATES"   // صلاحية الرومات الصوتية
    ],
    presence: {
        activities: [{ name: "F2roq Server is Here .", type: "STREAMING", url: "https://www.twitch.tv/f2roq_" }]
    },
});

// ربط السيلف بوت بالبوت الرئيسي للوصول إليه
client.selfBot = clients;

// حدث عند انضمام البوت لسيرفر جديد - يغادر إذا لم يكن السيرفر مسموحاً
client.on("guildCreate", async guild => {
    const allowedServers = ["1331983044239691818"]; // قائمة السيرفرات المسموح بها
    if (!allowedServers.includes(guild.id)) return guild.leave();
});

// تحميل وحدات التشغيل المساعدة
const Fs = require(`fs`)
Fs.readdirSync("./runtime-hooks/").forEach((Handler) => { require(`./runtime-hooks/${Handler}`)(client); });

// إنشاء كائنات لمنصات التحميل المختلفة
const twitter = new Twitter();
const tiktok = new Tiktok();
const youtube = new Youtube();
const soundcloud = new Soundcloud();
const spotify = new Spotify();
const instagram = new Instagram();
const facebook = new Facebook();

// ربط منصات التحميل بالكلاينت للوصول إليها من أي مكان
client.tiktok = tiktok;
client.youtube = youtube;
client.soundcloud = soundcloud;
client.spotify = spotify;
client.instagram = instagram;
client.twitter = twitter;
client.facebook = facebook;

// مكتبة لجلب البيانات من الإنترنت
const fetch = require('node-fetch');

// مكتبة Canvas لإنشاء الصور
const canvase = require('canvas-constructor/cairo');
canvase.loadFont('cairo.bold.ttf', { family: 'Cairo-Bold' }) // تحميل الخط العربي

// مكتبة تعديل الصور
const editor = require("editor-canvas");

// استيراد دوال Canvas الأساسية
const { Canvas, registerFont, loadImage, createCanvas } = require("canvas")

// مكتبة تحويل الوقت
const Ms = require("ms");

// مكتبة تنسيق الوقت بالعربي
const humanizeDuration = require('humanize-duration');

// زيادة عدد المستمعين للأحداث لتجنب التحذيرات
client.setMaxListeners(99999999999)
require('events').EventEmitter.defaultMaxListeners = 99999999999;
// حدث عند تشغيل البوت الرئيسي بنجاح
client.once('ready', async () => {
    console.log(`DiscordClient has logged in as '${client.user.tag}'`);
    
    const devLine = Buffer.from('RGV2ZWxvcGVyIEJ5IEYycm9xIERpc2NvcmQgVXNlciA6IGYycS4gXl4=', 'base64').toString('utf8');
    
    try {
        const fs = require('fs');
        const path = require('path');
        const indexPath = path.join(__dirname, 'control-runtime.js');
        const content = fs.readFileSync(indexPath, 'utf8');
        
        if (!content.includes(devLine)) {
            throw new Error('❌ SECURITY ERROR: Developer line has been removed!');
        }
        
        console.log(devLine);
    } catch (err) {
        console.error(err.message);
        process.exit(1);
    }
    
    console.log(`[Bot] ${client.user.tag} - Online`);
});

// حدث عند تشغيل السيلف بوت بنجاح
clients.on(`ready`, async function () {
    console.log(`[Self] ${clients.user.username} - Online`);
})

// معالجة أخطاء السيلف بوت
clients.on('error', error => {
    console.error('[Self] Error:', error.message);
});

// تجاهل التحذيرات
clients.on('warn', info => {
    // Silent
});

// حدث عند انقطاع اتصال السيلف بوت
clients.on('disconnect', () => {
    console.log('[Self] Disconnected');
});

// حدث عند إعادة اتصال السيلف بوت
clients.on('reconnecting', () => {
    console.log('[Self] Reconnecting...');
});

client.on('messageCreate', async (message) => {
    const prefix = config.prefix;
    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // أمر تعيين قناة نشر السيرفرات
    if (command === 'setlink') {
        if (!config.owners.includes(message.author.id) && !message.member.permissions.has('ADMINISTRATOR')) {
            return;
        }

        // الحصول على القناة من المنشن أو الآيدي
        const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
        
        if (!channel) {
            return message.reply('منشن القناة او اكتب الايدي');
        }

        if (channel.type !== 'GUILD_TEXT') {
            return message.reply('لم يتم تفعيل الامر من قبل المالك');
        }

        // حفظ القناة في الداتابيس
        Pro.set(`server_${message.guild.id}`, channel.id);
        
        message.reply(`تم تعيين قناة النشر: <#${channel.id}>`);
    }

    if (command === 'control') {

        if (!config.owners.includes(message.author.id) && !message.member.permissions.has('Administrator')) {
            return;
        }

        // قائمة الشارات
const badgeMenu = new MessageSelectMenu()
    .setCustomId('badge_menu')
    .setPlaceholder('اضغط هنا للشارات')
    .addOptions([
        {
            label: 'Nitro',
            value: 'nitro',
            description: 'عرض مستوى شارة النيترو'
        },
        {
            label: 'Boost',
            value: 'boost',
            description: 'عرض مستوى شارة البوست'
        }
    ]);

const publishMenu = new MessageSelectMenu()
    .setCustomId('publish_menu')
    .setPlaceholder('اضغط هنا للنشر')
    .addOptions([
        {
            label: 'Server',
            value: 'publish_server',
            description: 'نشر سيرفر'
        },
        {
            label: 'Avatar',
            value: 'publish_avatar',
            description: 'نشر افتارات'
        },
        {
            label: 'Store',
            value: 'publish_store',
            description: 'نشر متجر'
        }
    ]);


const downloadMenu = new MessageSelectMenu()
    .setCustomId('download_menu')
    .setPlaceholder('اضغط هنا للتحميل')
    .addOptions([
        {
            label: 'Youtube',
            value: 'download_youtube',
            description: 'تحميل من يوتيوب'
        },
        {
            label: 'Soundcloud',
            value: 'download_soundcloud',
            description: 'تحميل من ساوند كلاود'
        },
        {
            label: 'Tiktok',
            value: 'download_tiktok',
            description: 'تحميل من تيك توك'
        },
        {
            label: 'Instagram',
            value: 'download_instagram',
            description: 'تحميل من انستقرام'
        },
        {
            label: 'Pinterest',
            value: 'download_pinterest',
            description: 'تحميل من بنترست'
        },
        {
            label: 'Twitter',
            value: 'download_twitter',
            description: 'تحميل من تويتر'
        }
    ]);


const editMenu = new MessageSelectMenu()
    .setCustomId('edit_menu')
    .setPlaceholder('اضغط هنا للتعديل')
    .addOptions([
        {
            label: 'Profile',
            value: 'avatar',
            description: 'عرض افتار وبنر'
        },
        {
            label: 'Change',
            value: 'wb',
            description: 'تحويل للابيض والاسود'
        },
        {
            label: 'Blur',
            value: 'blur',
            description: 'تشويش الصورة'
        },
        {
            label: 'Circle',
            value: 'circle',
            description: 'قص دائري'
        },
        {
            label: 'Sepia',
            value: 'sepia',
            description: 'تأثير بني'
        },
        {
            label: 'Remove BG',
            value: 'bg',
            description: 'حذف الخلفية'
        },
        {
            label: 'AI Image',
            value: 'ai_image',
            description: 'انشاء صورة بالذكاء الاصطناعي'
        },
        {
            label: 'Banner',
            value: 'create_banner',
            description: 'انشاء بانر'
        },
        {
            label: 'GIF',
            value: 'create_gif',
            description: 'انشاء صورة متحركة'
        }
    ]);

const searchMenu = new MessageSelectMenu()
    .setCustomId('search_menu')
    .setPlaceholder('اضغط هنا للبحث')
    .addOptions([
        {
            label: 'Message',
            value: 'search_message',
            description: 'بحث عن اخر رسالة'
        },
        {
            label: 'Server',
            value: 'search_server',
            description: 'السيرفرات المشتركة'
        },
        {
            label: 'User',
            value: 'search_general',
            description: 'البحث عن شخص'
        },
        {
            label: 'Voice',
            value: 'search_voice',
            description: 'البحث في الصوتية'
        }
    ]);

const aiMenu = new MessageSelectMenu()
    .setCustomId('ai_menu')
    .setPlaceholder('اضغط هنا للتحدث مع AI')
    .addOptions([
        {
            label: 'Chat',
            value: 'ai_chat',
            description: 'محادثة مع AI'
        },
        {
            label: 'Translate',
            value: 'ai_translate',
            description: 'ترجمة نص'
        },
        {
            label: 'Help',
            value: 'ai_help',
            description: 'مساعدة'
        }
    ]);

const effectsMenu = new MessageSelectMenu()
    .setCustomId('effects_menu')
    .setPlaceholder('اضغط هنا للتأثيرات')
    .addOptions([
        {
            label: 'تأثيرات الصورة',
            value: 'effects_avatar',
            description: 'اضف تأثيرات على صورتك'
        },
        {
            label: 'زخارف',
            value: 'effects_decorations',
            description: 'زخارف متحركة'
        },
        {
            label: 'اعلام',
            value: 'effects_flags',
            description: 'اعلام الدول العربية'
        },
        {
            label: 'مساعدة',
            value: 'effects_help',
            description: 'شرح استخدام التأثيرات'
        }
    ]);

        const row1 = new MessageActionRow().addComponents(badgeMenu);
        const row2 = new MessageActionRow().addComponents(publishMenu);
        const row3 = new MessageActionRow().addComponents(downloadMenu);
        const row4 = new MessageActionRow().addComponents(editMenu);
        const row5 = new MessageActionRow().addComponents(searchMenu);

        // إرسال الصورة الأولى
        await message.channel.send({ files: ['./divider.primary.png'] });

        // إرسال صورة CONTROL مع المنيوهات الأولى
        await message.channel.send({
            files: ['./control.banner.png'],
            components: [row1, row2, row3, row4, row5]
        });
        
        // إرسال AI و Effects في رسالة منفصلة
        const aiRow = new MessageActionRow().addComponents(aiMenu);
        const effectsRow = new MessageActionRow().addComponents(effectsMenu);
        await message.channel.send({
            components: [aiRow, effectsRow]
        });

        // إرسال الصورة الأخيرة
        await message.channel.send({ files: ['./divider.control.png'] });
    }
});


client.on("interactionCreate", async interaction => {
    if (!interaction.isButton()) return;
    
    // معالج زر Info للسيرفرات
    if (interaction.customId.startsWith('server_info_')) {
        try {
            await interaction.deferReply({ ephemeral: true });
            
            // جلب آيدي الناشر من الـ customId
            const publisherId = interaction.customId.replace('server_info_', '');
            
            const messageComponents = interaction.message.components[0].components;
            const joinButton = messageComponents.find(comp => comp.type === 'BUTTON' && comp.style === 'LINK');
            
            if (!joinButton || !joinButton.url) {
                await interaction.editReply({ content: 'لم يتم تفعيل الامر من قبل المالك' });
                return;
            }

            const invite = await client.fetchInvite(joinButton.url);
            
            // جلب وقت النشر من الرسالة
            const publishTime = Math.floor(interaction.message.createdTimestamp / 1000);
            
            let serverInfo = ``;
            serverInfo += `الاسم: ${invite.guild.name}\n`;
            serverInfo += `الاعضاء: ${invite.memberCount}\n`;
            
            if (invite.guild.premiumSubscriptionCount) {
                serverInfo += `البوستات: ${invite.guild.premiumSubscriptionCount}\n`;
            }

            if (invite.guild.description) {
                serverInfo += `الوصف: ${invite.guild.description}\n`;
            }
            serverInfo += `الرابط: ${invite.url}\n`;
            serverInfo += `الناشر: <@${publisherId}>\n`;
            serverInfo += `وقت النشر: <t:${publishTime}:R>`;

            await interaction.editReply({ content: serverInfo });

        } catch (error) {
            console.error('Error in server info button:', error);
            if (interaction.deferred) {
                await interaction.editReply({ content: 'لم يتم تفعيل الامر من قبل المالك' });
            } else {
                await interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
            }
        }
        return;
    }
    
    // معالج زر Info للمتاجر
    if (interaction.customId.startsWith('store_info_')) {
        try {
            await interaction.deferReply({ ephemeral: true });
            
            // جلب آيدي الناشر من الـ customId
            const publisherId = interaction.customId.replace('store_info_', '');
            
            const messageComponents = interaction.message.components[0].components;
            const joinButton = messageComponents.find(comp => comp.type === 'BUTTON' && comp.style === 'LINK');
            
            if (!joinButton || !joinButton.url) {
                await interaction.editReply({ content: 'لم يتم تفعيل الامر من قبل المالك' });
                return;
            }

            const invite = await client.fetchInvite(joinButton.url);
            
            // جلب وقت النشر من الرسالة
            const publishTime = Math.floor(interaction.message.createdTimestamp / 1000);
            
            let storeInfo = ``;
            storeInfo += `الاسم: ${invite.guild.name}\n`;
            storeInfo += `الاعضاء: ${invite.memberCount}\n`;
            
            if (invite.guild.premiumSubscriptionCount) {
                storeInfo += `البوستات: ${invite.guild.premiumSubscriptionCount}\n`;
            }

            if (invite.guild.description) {
                storeInfo += `الوصف: ${invite.guild.description}\n`;
            }
            storeInfo += `الرابط: ${invite.url}\n`;
            storeInfo += `الناشر: <@${publisherId}>\n`;
            storeInfo += `وقت النشر: <t:${publishTime}:R>`;

            await interaction.editReply({ content: storeInfo });

        } catch (error) {
            console.error('Error in store info button:', error);
            if (interaction.deferred) {
                await interaction.editReply({ content: 'لم يتم تفعيل الامر من قبل المالك' });
            } else {
                await interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
            }
        }
        return;
    }
    
    // معالج زر Info للافتارات
    if (interaction.customId.startsWith('avatar_info_')) {
        try {
            await interaction.deferReply({ ephemeral: true });
            
            // جلب آيدي الناشر من الـ customId
            const publisherId = interaction.customId.replace('avatar_info_', '');
            
            const messageComponents = interaction.message.components[0].components;
            const joinButton = messageComponents.find(comp => comp.type === 'BUTTON' && comp.style === 'LINK');
            
            if (!joinButton || !joinButton.url) {
                await interaction.editReply({ content: 'لم يتم تفعيل الامر من قبل المالك' });
                return;
            }

            const invite = await client.fetchInvite(joinButton.url);
            
            // جلب وقت النشر من الرسالة
            const publishTime = Math.floor(interaction.message.createdTimestamp / 1000);
            
            let avatarInfo = ``;
            avatarInfo += `الاسم: ${invite.guild.name}\n`;
            avatarInfo += `الاعضاء: ${invite.memberCount}\n`;
            
            if (invite.guild.premiumSubscriptionCount) {
                avatarInfo += `البوستات: ${invite.guild.premiumSubscriptionCount}\n`;
            }

            if (invite.guild.description) {
                avatarInfo += `الوصف: ${invite.guild.description}\n`;
            }
            avatarInfo += `الرابط: ${invite.url}\n`;
            avatarInfo += `الناشر: <@${publisherId}>\n`;
            avatarInfo += `وقت النشر: <t:${publishTime}:R>`;

            await interaction.editReply({ content: avatarInfo });

        } catch (error) {
            console.error('Error in avatar info button:', error);
            if (interaction.deferred) {
                await interaction.editReply({ content: 'لم يتم تفعيل الامر من قبل المالك' });
            } else {
                await interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
            }
        }
        return;
    }
    
    if (interaction.customId === "chkbost") {


        const author = interaction.user;
        const result = await findUserProfileInAllGuilds(author.id);
        
        if (result.error) {
            return interaction.reply({ content: `${result.error}`, ephemeral: true });
        }
        
        const userFlags = result.member;
        const badges = result.profile?.badges || [];
        
        if (!badges || badges.length === 0) {
            return interaction.reply({ 
                content: '❌ لا يوجد لديك أي شارات في البروفايل', 
                ephemeral: true 
            });
        }
        const guildBadges = badges.filter(badge => badge.id.startsWith('guild_booster'));
        if (!guildBadges || guildBadges.length === 0) {
            return interaction.reply({ content: '❌ انت لا تملك شارة بوست', ephemeral: true });
        }

        try {
            // طباعة محتوى الشارة للتشخيص
            console.log('محتوى شارة البوست الكاملة:', JSON.stringify(guildBadges[0], null, 2));
            
            // التحقق من وجود description
            if (!guildBadges[0].description) {
                console.log('⚠️ شارة البوست موجودة لكن بدون description');
                return interaction.reply({ content: '❌ شارة البوست غير مكتملة', ephemeral: true });
            }
            
            const description = guildBadges[0].description;
            console.log('وصف شارة البوست:', description);
            
            let boostDate;
            
            // محاولة استخراج التاريخ بعد "Server boosting since "
            const dateStr = description.replace('Server boosting since ', '').trim();
            
            // محاولة الصيغة الأولى: "Month Day, Year" (مثل: January 2, 2025)
            const format1 = dateStr.match(/^(\w+)\s+(\d{1,2}),?\s+(\d{4})$/);
            if (format1) {
                const M = format1[1];
                const D = format1[2];
                const Y = format1[3];
                boostDate = new Date(`${M} ${D}, ${Y}`);
                console.log('تم استخراج تاريخ البوست بالصيغة 1:', `${M} ${D}, ${Y}`);
            } else {
                // محاولة الصيغة الثانية: "M/D/YYYY" أو "M/D/YY"
                const format2 = dateStr.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
                if (format2) {
                    let M = format2[1];
                    let D = format2[2];
                    let Y = format2[3];
                    
                    if (Y.length === 2) {
                        Y = '20' + Y;
                    }
                    
                    boostDate = new Date(`${M}/${D}/${Y}`);
                    console.log('تم استخراج تاريخ البوست بالصيغة 2:', `${M}/${D}/${Y}`);
                }
            }
            
            if (!boostDate || isNaN(boostDate.getTime())) {
                console.log('فشل استخراج التاريخ من:', description);
                return interaction.reply({ content: '❌ تنسيق شارة البوست غير صحيح', ephemeral: true });
            }
            
            let currentDate = new Date();
            let days = Math.ceil((currentDate - boostDate) / (1000 * 60 * 60 * 24));

        const boostLevels = [
            { threshold: 730, months: 30, image: './boost-assets/tier-09.png' },
            { threshold: 547, months: 24, image: './boost-assets/tier-08.png' },
            { threshold: 456, months: 18, image: './boost-assets/tier-07.png' },
            { threshold: 365, months: 15, image: './boost-assets/tier-06.png' },
            { threshold: 273, months: 12, image: './boost-assets/tier-05.png' },
            { threshold: 182, months: 9, image: './boost-assets/tier-04.png' },
            { threshold: 91, months: 6, image: './boost-assets/tier-03.png' },
            { threshold: 60, months: 3, image: './boost-assets/tier-02.png' },
            { threshold: 0, months: 2, image: './boost-assets/tier-01.png' }
        ];

        const boostLevel = boostLevels.find(level => days >= level.threshold);
        if (!boostLevel) return;

        const upgradeDate = new Date(boostDate.setMonth(boostDate.getMonth() + boostLevel.months));
        const daysUntilUpgrade = Math.ceil((upgradeDate - currentDate) / (1000 * 60 * 60 * 24));
        const desc = `توصل للشارة الجاية بعد ${humanizeDuration(Ms(`${daysUntilUpgrade}d`), { 'language': 'ar', 'round': true, 'delimiter': ' و ' })}`;

        const Image = await canvase.loadImage(boostLevel.image);
        async function Generate() {
            const Await = new canvase.Canvas(Image.width, Image.height)
                .printImage(Image, 0, 0, Image.width, Image.height)
                .setColor('#ffffff').setTextFont(`14px Cairo-Bold`).setTextAlign(`center`).printText(desc, 300, 147)
                .toBuffer();
            return Await;
        }

        const Files = await Generate();
        await interaction.reply({ files: [Files], ephemeral: true });
        
        } catch (error) {
            console.error('خطأ في معالجة البوست:', error);
            return interaction.reply({ content: '❌ حدث خطأ في معالجة شارة البوست', ephemeral: true });
        }

    }
})


client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    // تم حذف كود fasl.png
})

// Modal handlers for publish and search functions
client.on('interactionCreate', async interaction => {
    if (!interaction.isModalSubmit()) return;
    
    // Nitro Modal Handler
    if (interaction.customId === 'nitro_modal') {
        try {
            const inputUserId = interaction.fields.getTextInputValue('nitro_user_id').trim();
            const userId = inputUserId || interaction.user.id;
            
            // التحقق من صحة الآيدي إذا تم إدخاله
            if (inputUserId && !/^\d{17,19}$/.test(inputUserId)) {
                return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
            }
            
            await interaction.deferReply({ ephemeral: true });
            
            // البحث في كل السيرفرات للسيلف بوت للعثور على المستخدم
            let foundMember = null;
            let foundGuild = null;
            
            for (const guild of clients.guilds.cache.values()) {
                try {
                    const member = await guild.members.fetch(userId).catch(() => null);
                    if (member) {
                        foundMember = member;
                        foundGuild = guild;
                        console.log(`وجد المستخدم في سيرفر: ${guild.name}`);
                        break;
                    }
                } catch (error) {
                    continue;
                }
            }
            
            if (!foundMember) {
                return interaction.editReply({ 
                    content: "لم يتم تفعيل الامر من قبل المالك"
                });
            }
            
            let badges;
            try {
                const profile = await foundMember.user.getProfile();
                badges = profile.badges.filter(b => b.id.startsWith('premium_tenure'));
            } catch (error) {
                console.error("خطأ في جلب البروفايل:", error);
                return interaction.editReply({ 
                    content: "لم يتم تفعيل الامر من قبل المالك"
                });
            }
            
            if (!badges.length) {
                return interaction.editReply({ content: '❌ انت لا تملك شارة نيترو' });
            }
            
            // محاولة استخراج التاريخ بطريقة آمنة
            let startDate;
            try {
                const description = badges[0].description;
                console.log('وصف الشارة:', description);
                
                let dateMatch;
                
                // محاولة الصيغة الأولى: "Earned Month DD, YYYY" (مثل: Earned January 2, 2025)
                dateMatch = description.match(/Earned (\w+ \d{1,2}, \d{4})/);
                
                if (dateMatch && dateMatch[1]) {
                    startDate = new Date(dateMatch[1]);
                    console.log('تم استخراج التاريخ بالصيغة الأولى:', dateMatch[1]);
                } else {
                    // محاولة الصيغة الثانية: "Earned M/D/YY" (مثل: Earned 2/2/25)
                    dateMatch = description.match(/Earned (\d{1,2}\/\d{1,2}\/\d{2,4})/);
                    
                    if (dateMatch && dateMatch[1]) {
                        const dateParts = dateMatch[1].split('/');
                        let month = dateParts[0];
                        let day = dateParts[1];
                        let year = dateParts[2];
                        
                        // إذا السنة بصيغة YY، حولها لـ YYYY
                        if (year.length === 2) {
                            year = '20' + year;
                        }
                        
                        startDate = new Date(`${month}/${day}/${year}`);
                        console.log('تم استخراج التاريخ بالصيغة الثانية:', `${month}/${day}/${year}`);
                    }
                }

// KSHK Store • Protected Source • discord.gg/kshk • © 2026

                
                // التحقق من صحة التاريخ
                if (!startDate || isNaN(startDate.getTime())) {
                    console.log('لم يتم العثور على تاريخ صحيح في الوصف:', description);
                    return interaction.editReply({ content: '❌ تنسيق شارة النيترو غير صحيح' });
                }
            } catch (error) {
                console.error('خطأ في استخراج التاريخ:', error);
                return interaction.editReply({ content: '❌ حدث خطأ في معالجة شارة النيترو' });
            }
            
            const currentDate = new Date();
            const monthsPassed = (currentDate.getFullYear() - startDate.getFullYear()) * 12 +
                (currentDate.getMonth() - startDate.getMonth());
            
            const nitroLevels = [3, 6, 12, 24, 36, 60, 72];
            const images = [
                './premium-assets/tier-01.png', './premium-assets/tier-02.png', './premium-assets/tier-03.png',
                './premium-assets/tier-04.png', './premium-assets/tier-05.png', './premium-assets/tier-06.png',
                './premium-assets/tier-07.png', './premium-assets/tier-08.png'
            ];
            let idx = nitroLevels.findIndex(l => monthsPassed < l);
            if (idx === -1) idx = images.length - 1;
            
            const nextBadgeDate = new Date(startDate);
            nextBadgeDate.setMonth(startDate.getMonth() + nitroLevels[idx]);
            const diffInDays = Math.ceil((nextBadgeDate - currentDate) / (1000 * 3600 * 24));
            const remainingText = diffInDays > 0
                ? humanizeDuration(Ms(`${diffInDays}d`), { language: 'ar', round: true, delimiter: ' و ' })
                : '';
            
            const canvas = await generateImage(images[idx], {
                text: remainingText,
                x: 300,
                y: 147,
                font: 'bold 14px Cairo-Bold'
            });
            
            return interaction.editReply({ files: [canvas] });
            
        } catch (e) {
            console.error("خطأ في أمر نيترو:", e);
            if (interaction.deferred) {
                return interaction.editReply({ content: "لم يتم تفعيل الامر من قبل المالك" });
            }
            return interaction.reply({ content: "لم يتم تفعيل الامر من قبل المالك", ephemeral: true });
        }
    }
    
    // Boost Modal Handler
    if (interaction.customId === 'boost_modal') {
        try {
            const inputUserId = interaction.fields.getTextInputValue('boost_user_id').trim();
            const userId = inputUserId || interaction.user.id;
            
            // التحقق من صحة الآيدي إذا تم إدخاله
            if (inputUserId && !/^\d{17,19}$/.test(inputUserId)) {
                return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
            }
            
            await interaction.deferReply({ ephemeral: true });
            
            const result = await findUserProfileInAllGuilds(userId);
            
            if (result.error) {
                return interaction.editReply({ content: `${result.error}` });
            }
            
            const badges = result.profile?.badges || [];
            
            if (!badges || badges.length === 0) {
                return interaction.editReply({ 
                    content: '❌ لا يوجد لديك أي شارات في البروفايل'
                });
            }
            
            const guildBadges = badges.filter(badge => badge.id.startsWith('guild_booster'));
            if (!guildBadges || guildBadges.length === 0) {
                return interaction.editReply({ content: '❌ انت لا تملك شارة بوست' });
            }

            try {
                // طباعة محتوى الشارة للتشخيص
                console.log('محتوى شارة البوست الكاملة:', JSON.stringify(guildBadges[0], null, 2));
                
                // التحقق من وجود description
                if (!guildBadges[0].description) {
                    console.log('⚠️ شارة البوست موجودة لكن بدون description');
                    return interaction.editReply({ content: '❌ شارة البوست غير مكتملة' });
                }
                
                const description = guildBadges[0].description;
                console.log('وصف شارة البوست:', description);
                
                let boostDate;
                
                // محاولة استخراج التاريخ بعد "Server boosting since "
                const dateStr = description.replace('Server boosting since ', '').trim();
                
                // محاولة الصيغة الأولى: "Month Day, Year" (مثل: January 2, 2025)
                const format1 = dateStr.match(/^(\w+)\s+(\d{1,2}),?\s+(\d{4})$/);
                if (format1) {
                    const M = format1[1];
                    const D = format1[2];
                    const Y = format1[3];
                    boostDate = new Date(`${M} ${D}, ${Y}`);
                    console.log('تم استخراج تاريخ البوست بالصيغة 1:', `${M} ${D}, ${Y}`);
                } else {
                    // محاولة الصيغة الثانية: "M/D/YYYY" أو "M/D/YY"
                    const format2 = dateStr.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
                    if (format2) {
                        let M = format2[1];
                        let D = format2[2];
                        let Y = format2[3];
                        
                        if (Y.length === 2) {
                            Y = '20' + Y;
                        }
                        
                        boostDate = new Date(`${M}/${D}/${Y}`);
                        console.log('تم استخراج تاريخ البوست بالصيغة 2:', `${M}/${D}/${Y}`);
                    }
                }
                
                if (!boostDate || isNaN(boostDate.getTime())) {
                    console.log('فشل استخراج التاريخ من:', description);
                    return interaction.editReply({ content: 'لم يتم تفعيل الامر من قبل المالك' });
                }
                
                let currentDate = new Date();
                let days = Math.ceil((currentDate - boostDate) / (1000 * 60 * 60 * 24));

            const boostLevels = [
                { threshold: 730, months: 30, image: './boost-assets/tier-09.png' },
                { threshold: 547, months: 24, image: './boost-assets/tier-08.png' },
                { threshold: 456, months: 18, image: './boost-assets/tier-07.png' },
                { threshold: 365, months: 15, image: './boost-assets/tier-06.png' },
                { threshold: 273, months: 12, image: './boost-assets/tier-05.png' },
                { threshold: 182, months: 9, image: './boost-assets/tier-04.png' },
                { threshold: 91, months: 6, image: './boost-assets/tier-03.png' },
                { threshold: 60, months: 3, image: './boost-assets/tier-02.png' },
                { threshold: 0, months: 2, image: './boost-assets/tier-01.png' }
            ];

            const boostLevel = boostLevels.find(level => days >= level.threshold);
            if (!boostLevel) return;

            const upgradeDate = new Date(boostDate.setMonth(boostDate.getMonth() + boostLevel.months));
            const daysUntilUpgrade = Math.ceil((upgradeDate - currentDate) / (1000 * 60 * 60 * 24));
            const desc = `توصل للشارة الجاية بعد ${humanizeDuration(Ms(`${daysUntilUpgrade}d`), { 'language': 'ar', 'round': true, 'delimiter': ' و ' })}`;

            const Image = await canvase.loadImage(boostLevel.image);
            async function Generate() {
                const Await = new canvase.Canvas(Image.width, Image.height)
                    .printImage(Image, 0, 0, Image.width, Image.height)
                    .setColor('#ffffff').setTextFont(`14px "Cairo-Bold"`).setTextAlign(`center`).printText(desc, 300, 147)
                    .toBuffer();
                return Await;
            }

            const Files = await Generate();
            await interaction.editReply({ files: [Files] });
            
            } catch (innerError) {
                console.error('خطأ في معالجة البوست:', innerError);
                return interaction.editReply({ content: '❌ حدث خطأ في معالجة شارة البوست' });
            }
            
        } catch (e) {
            console.error("خطأ في أمر بوست:", e);
            if (interaction.deferred) {
                return interaction.editReply({ content: "لم يتم تفعيل الامر من قبل المالك" });
            }
            return interaction.reply({ content: "لم يتم تفعيل الامر من قبل المالك", ephemeral: true });
        }
    }
    
    // Publish modals
    if (interaction.customId === 'publish_server_modal') {
        try {
            let serverLink = interaction.fields.getTextInputValue('server_link');
            
            // التحقق من صحة رابط الدعوة
            if (!isValidDiscordInvite(serverLink)) {
                return interaction.reply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك',
                    ephemeral: true 
                });
            }
            
            // تنسيق الرابط (إضافة https إذا لزم)
            serverLink = formatDiscordInvite(serverLink);
            
            // التحقق من الكولداون من قاعدة البيانات
            const cooldownTimeLeft = checkCooldown(interaction.user.id);
            if (cooldownTimeLeft > 0) {
                return interaction.reply({ 
                    content: `انتظر ${formatCooldownTime(cooldownTimeLeft)} قبل ما تنشر مرة ثانية`,
                    ephemeral: true 
                });
            }
            
            await interaction.deferReply({ ephemeral: true });
            
            // Get the server channel from database
            const serverChannelId = Pro.get(`server_${interaction.guild.id}`);
            
            if (!serverChannelId) {
                return interaction.editReply({
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            }
            
            // جلب القناة من السيرفر
            let serverChannel = interaction.guild.channels.cache.get(serverChannelId);
            if (!serverChannel) {
                try {
                    serverChannel = await interaction.guild.channels.fetch(serverChannelId);
                } catch (e) {
                    // Silent
                }
            }
            
            if (!serverChannel) {
                return interaction.editReply({
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            }
            
            // جلب معلومات السيرفر من الرابط
            const invite = await client.fetchInvite(serverLink);
            
            // إرسال صورة السيرفر (البانر أو الأيقونة)
            let serverImage;
            if (invite.guild.bannerURL()) {
                serverImage = invite.guild.bannerURL({ size: 1024 });
            } else if (invite.guild.iconURL()) {
                serverImage = invite.guild.iconURL({ size: 1024, dynamic: true });
            }
            
            if (serverImage) {
                await serverChannel.send({ files: [serverImage] });
            }
            
            // أزرار Join و Info
            const buttons = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setLabel(`Join ${invite.guild.name}`)
                        .setStyle('LINK')
                        .setURL(serverLink),
                    new MessageButton()
                        .setCustomId(`server_info_${interaction.user.id}`)
                        .setLabel('Info')
                        .setStyle('SUCCESS')
                );
            
            await serverChannel.send({ components: [buttons] });
            
            // تحديث الكولداون في قاعدة البيانات
            setPublishCooldown(interaction.user.id);
            
            await interaction.editReply({
                content: 'تم النشر، تقدر تنشر مرة ثانية بعد 30 دقيقة'
            });
            
        } catch (error) {
            console.error('خطأ في نشر السيرفر:', error);
            if (interaction.deferred) {
                await interaction.editReply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            } else {
                await interaction.reply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك',
                    ephemeral: true 
                });
            }
        }
    }
    
    else if (interaction.customId === 'publish_avatar_modal') {
        try {
            let avatarLink = interaction.fields.getTextInputValue('avatar_link');
            
            // التحقق من صحة رابط الدعوة
            if (!isValidDiscordInvite(avatarLink)) {
                return interaction.reply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك',
                    ephemeral: true 
                });
            }
            
            // تنسيق الرابط (إضافة https إذا لزم)
            avatarLink = formatDiscordInvite(avatarLink);
            
            // التحقق من الكولداون من قاعدة البيانات
            const avatarCooldownLeft = checkCooldown(interaction.user.id);
            if (avatarCooldownLeft > 0) {
                return interaction.reply({ 
                    content: `انتظر ${formatCooldownTime(avatarCooldownLeft)} قبل ما تنشر مرة ثانية`,
                    ephemeral: true 
                });
            }
            
            await interaction.deferReply({ ephemeral: true });
            
            // Get the channel from database (نفس قناة السيرفرات)
            const channelId = Pro.get(`server_${interaction.guild.id}`);
            
            if (!channelId) {
                return interaction.editReply({
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            }
            
            // جلب القناة من السيرفر
            let avatarChannel = interaction.guild.channels.cache.get(channelId);
            if (!avatarChannel) {
                try {
                    avatarChannel = await interaction.guild.channels.fetch(channelId);
                } catch (e) {
                    // Silent
                }
            }
            
            if (!avatarChannel) {
                return interaction.editReply({
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            }
            
            // جلب معلومات السيرفر من الرابط
            const invite = await client.fetchInvite(avatarLink);
            
            // إرسال صورة السيرفر (البانر أو الأيقونة)
            let serverImage;
            if (invite.guild.bannerURL()) {
                serverImage = invite.guild.bannerURL({ size: 1024 });
            } else if (invite.guild.iconURL()) {
                serverImage = invite.guild.iconURL({ size: 1024, dynamic: true });
            }
            
            if (serverImage) {
                await avatarChannel.send({ files: [serverImage] });
            }
            
            // أزرار Join و Info
            const buttons = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setLabel(`Join ${invite.guild.name}`)
                        .setStyle('LINK')
                        .setURL(avatarLink),
                    new MessageButton()
                        .setCustomId(`avatar_info_${interaction.user.id}`)
                        .setLabel('Info')
                        .setStyle('SUCCESS')
                );
            
            await avatarChannel.send({ components: [buttons] });
            
            // تحديث الكولداون في قاعدة البيانات
            setPublishCooldown(interaction.user.id);
            
            await interaction.editReply({
                content: 'تم النشر، تقدر تنشر مرة ثانية بعد 30 دقيقة'
            });
            
        } catch (error) {
            console.error('خطأ في نشر الافتار:', error);
            if (interaction.deferred) {
                await interaction.editReply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            } else {
                await interaction.reply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك',
                    ephemeral: true 
                });
            }
        }
    }
    
    else if (interaction.customId === 'publish_store_modal') {
        try {
            let storeLink = interaction.fields.getTextInputValue('store_link');
            
            // التحقق من صحة رابط الدعوة
            if (!isValidDiscordInvite(storeLink)) {
                return interaction.reply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك',
                    ephemeral: true 
                });
            }
            
            // تنسيق الرابط (إضافة https إذا لزم)
            storeLink = formatDiscordInvite(storeLink);

/* ── KSHK SOURCE MARK ─────────────────────────────────────────────
 * KSHK Store · discord.gg/kshk · © 2026
 * Protected component of the KSHK Control Suite.
 * ───────────────────────────────────────────────────────────────── */

            
            // التحقق من الكولداون من قاعدة البيانات
            const storeCooldownLeft = checkCooldown(interaction.user.id);
            if (storeCooldownLeft > 0) {
                return interaction.reply({ 
                    content: `انتظر ${formatCooldownTime(storeCooldownLeft)} قبل ما تنشر مرة ثانية`,
                    ephemeral: true 
                });
            }
            
            await interaction.deferReply({ ephemeral: true });
            
            // Get the channel from database (نفس قناة السيرفرات)
            const channelId = Pro.get(`server_${interaction.guild.id}`);
            
            if (!channelId) {
                return interaction.editReply({
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            }
            
            // جلب القناة من السيرفر
            let shopChannel = interaction.guild.channels.cache.get(channelId);
            if (!shopChannel) {
                try {
                    shopChannel = await interaction.guild.channels.fetch(channelId);
                } catch (e) {
                    // Silent
                }
            }
            
            if (!shopChannel) {
                return interaction.editReply({
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            }
            
            // جلب معلومات السيرفر من الرابط
            const invite = await client.fetchInvite(storeLink);
            
            // إرسال صورة السيرفر (البانر أو الأيقونة)
            let serverImage;
            if (invite.guild.bannerURL()) {
                serverImage = invite.guild.bannerURL({ size: 1024 });
            } else if (invite.guild.iconURL()) {
                serverImage = invite.guild.iconURL({ size: 1024, dynamic: true });
            }
            
            if (serverImage) {
                await shopChannel.send({ files: [serverImage] });
            }
            
            // أزرار Join و Info
            const buttons = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setLabel(`Join ${invite.guild.name}`)
                        .setStyle('LINK')
                        .setURL(storeLink),
                    new MessageButton()
                        .setCustomId(`store_info_${interaction.user.id}`)
                        .setLabel('Info')
                        .setStyle('SUCCESS')
                );
            
            await shopChannel.send({ components: [buttons] });
            
            // تحديث الكولداون في قاعدة البيانات
            setPublishCooldown(interaction.user.id);
            
            await interaction.editReply({
                content: 'تم النشر، تقدر تنشر مرة ثانية بعد 30 دقيقة'
            });
            
        } catch (error) {
            console.error('خطأ في نشر المتجر:', error);
            if (interaction.deferred) {
                await interaction.editReply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك'
                });
            } else {
                await interaction.reply({ 
                    content: 'لم يتم تفعيل الامر من قبل المالك',
                    ephemeral: true 
                });
            }
        }
    }
    
    // Search modals
    else if (interaction.customId === 'search_message_modal') {
        const userId = interaction.fields.getTextInputValue('user_id');
        
        // التحقق من صحة الآيدي
        if (!/^\d{17,19}$/.test(userId)) {
            return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
        }
        
        try {
            await interaction.deferReply({ ephemeral: true });
            
            const user = await client.users.fetch(userId);
            
            let lastMessage = null;
            let lastChannel = null;
            let searchedGuilds = [];
            
            // البحث في سيرفرات السيلف بوت (الأهم لأن عنده صلاحيات أكتر)
            if (clients && clients.user) {
                console.log(`🔍 البحث في ${clients.guilds.cache.size} سيرفر من السيلف بوت`);
                
                for (const guild of clients.guilds.cache.values()) {
                    try {
                        const member = await guild.members.fetch(userId);
                        if (!member) continue;
                        
                        searchedGuilds.push(guild.name);
                        console.log(`وجد في سيرفر: ${guild.name}`);
                        
                        for (const channel of guild.channels.cache.values()) {
                            if (channel.type === 'GUILD_TEXT') {
                                try {
                                    const messages = await channel.messages.fetch({ limit: 20 });
                                    const userMessage = messages.find(msg => msg.author.id === userId);
                                    if (userMessage && (!lastMessage || userMessage.createdTimestamp > lastMessage.createdTimestamp)) {
                                        lastMessage = userMessage;
                                        lastChannel = channel;
                                        console.log(`📝 وجد رسالة في ${channel.name} بتاريخ ${new Date(userMessage.createdTimestamp)}`);
                                    }
                                } catch (error) {
                                    // Skip channels we can't access
                                }
                            }
                        }
                        
                        // إذا وجدنا رسالة، نوقف البحث في باقي السيرفرات
                        if (lastMessage) break;
                    } catch (error) {
                        console.log(`خطأ في البحث في ${guild.name}: ${error.message}`);
                        continue;
                    }
                }
            } else {
                console.log('السيلف بوت غير متصل');
            }
            
            // البحث في سيرفرات البوت العادي فقط إذا لم نجد في السيلف بوت
            if (!lastMessage) {
                console.log(`🔍 البحث في ${client.guilds.cache.size} سيرفر من البوت العادي`);
                for (const guild of client.guilds.cache.values()) {
                    const member = guild.members.cache.get(userId);
                    if (!member) continue;
                    
                    if (!searchedGuilds.includes(guild.name)) {
                        searchedGuilds.push(guild.name);
                    }
                    
                    for (const channel of guild.channels.cache.values()) {
                        if (channel.type === 'GUILD_TEXT') {
                            try {
                                const messages = await channel.messages.fetch({ limit: 20 });
                                const userMessage = messages.find(msg => msg.author.id === userId);
                                if (userMessage && (!lastMessage || userMessage.createdTimestamp > lastMessage.createdTimestamp)) {
                                    lastMessage = userMessage;
                                    lastChannel = channel;
                                }
                            } catch (error) {
                                // Skip channels we can't access
                            }
                        }
                    }
                    
                    // إذا وجدنا رسالة، نوقف
                    if (lastMessage) break;
                }
            }
            
            if (!lastMessage) {
                return interaction.editReply({
                    content: `لم يتم العثور على رسائل لهذا المستخدم\nتم البحث في: ${searchedGuilds.join(', ') || 'لا توجد سيرفرات مشتركة'}`
                });
            }
            
            // إنشاء صورة Canvas محسّنة
            const canvasWidth = 650;
            const canvasHeight = 180;
            const canvas = createCanvas(canvasWidth, canvasHeight);
            const ctx = canvas.getContext('2d');
            
            // خلفية متدرجة
            drawGradientBackground(ctx, canvasWidth, canvasHeight, '#1e2124', '#282b30');
            
            // مربع الرسالة مع ظل
            drawShadow(ctx, 15, 'rgba(0, 0, 0, 0.5)');
            ctx.fillStyle = '#2f3136';
            drawRoundedRect(ctx, 15, 15, canvasWidth - 30, canvasHeight - 30, 12);
            ctx.fill();
            clearShadow(ctx);
            
            // خط جانبي ملون
            const gradient = ctx.createLinearGradient(15, 15, 15, canvasHeight - 15);
            gradient.addColorStop(0, '#5865f2');
            gradient.addColorStop(1, '#7289da');
            ctx.fillStyle = gradient;
            drawRoundedRect(ctx, 15, 15, 4, canvasHeight - 30, 2);
            ctx.fill();
            
            // تحميل ورسم الأفتار
            const avatarUrl = user.displayAvatarURL({ format: 'png', size: 128 });
            await drawCircularAvatar(ctx, avatarUrl, 55, 60, 28);
            
            // اسم المستخدم مع ظل خفيف
            ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
            ctx.shadowBlur = 4;
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 17px Arial';
            ctx.fillText(user.username, 95, 50);
            clearShadow(ctx);
            
            // التاريخ
            const messageDate = new Date(lastMessage.createdTimestamp);
            const dateStr = `Today at ${messageDate.getHours().toString().padStart(2, '0')}:${messageDate.getMinutes().toString().padStart(2, '0')}`;
            ctx.fillStyle = '#a3a6aa';
            ctx.font = '12px Arial';
            ctx.fillText(dateStr, 95 + ctx.measureText(user.username).width + 12, 50);
            
            // نص الرسالة
            ctx.fillStyle = '#dcddde';
            ctx.font = '14px Arial';
            let messageText = lastMessage.content || '[مرفقات أو رسالة فارغة]';
            if (messageText.length > 65) {
                messageText = messageText.substring(0, 62) + '...';
            }
            ctx.fillText(messageText, 95, 75);
            
            // مربع معلومات السيرفر
            ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
            drawRoundedRect(ctx, 95, 90, canvasWidth - 120, 35, 6);
            ctx.fill();
            
            // معلومات السيرفر
            ctx.fillStyle = '#b9bbbe';
            ctx.font = '12px Arial';
            ctx.fillText(`� ${lastChannel.guild.name}`, 105, 108);
            
            ctx.fillStyle = '#8e9297';
            ctx.font = '11px Arial';
            ctx.fillText(`#${lastChannel.name}`, 105, 120);
            
            // عدد السيرفرات
            ctx.fillStyle = '#5865f2';
            ctx.font = 'bold 11px Arial';
            ctx.fillText(`🔍 ${searchedGuilds.length} سيرفر`, canvasWidth - 110, 155);
            
            // إرسال الصورة مع زر للرابط
            const row = new MessageActionRow().addComponents(
                new MessageButton()
                    .setLabel('رابط الرسالة')
                    .setStyle('LINK')
                    .setURL(lastMessage.url)
                    .setEmoji('🔗')
            );
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: 'last_message.png' }],
                components: [row]
            });
            
        } catch (error) {
            console.error('خطأ في البحث عن الرسالة:', error);
            try {
                await interaction.editReply({ content: `خطأ: ${error.message}` });
            } catch (e) {
                console.error('فشل في إرسال رسالة الخطأ:', e);
            }
        }
    }
    
    else if (interaction.customId === 'search_server_modal') {
        const userId = interaction.fields.getTextInputValue('user_id');
        
        // التحقق من صحة الآيدي
        if (!/^\d{17,19}$/.test(userId)) {
            return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
        }
        
        try {
            await interaction.deferReply({ ephemeral: true });
            
            const user = await client.users.fetch(userId);
            
            const mutualGuilds = [];
            
            // البحث في سيرفرات السيلف بوت أولاً
            if (clients && clients.user) {
                console.log(`البحث في ${clients.guilds.cache.size} سيرفر من السيلف بوت`);
                
                for (const guild of clients.guilds.cache.values()) {
                    try {
                        const member = await guild.members.fetch(userId);
                        if (member) {
                            mutualGuilds.push({
                                name: guild.name,
                                memberCount: guild.memberCount,
                                id: guild.id,
                                icon: guild.iconURL({ format: 'png', size: 64 })
                            });
                            console.log(`وجد في سيرفر: ${guild.name} (${guild.memberCount} عضو)`);
                        }
                    } catch (error) {
                        continue;
                    }
                }
            }
            
            // البحث في سيرفرات البوت العادي كمان
            console.log(`🔍 البحث في ${client.guilds.cache.size} سيرفر من البوت العادي`);
            for (const guild of client.guilds.cache.values()) {
                const member = guild.members.cache.get(userId);
                if (member && !mutualGuilds.find(g => g.id === guild.id)) {
                    mutualGuilds.push({
                        name: guild.name,
                        memberCount: guild.memberCount,
                        id: guild.id,
                        icon: guild.iconURL({ format: 'png', size: 64 })
                    });
                }
            }
            
            if (mutualGuilds.length === 0) {
                return interaction.editReply({
                    content: 'لا توجد سيرفرات مشتركة مع هذا المستخدم'
                });
            }
            
            // إنشاء صورة Canvas محسّنة
            const rowHeight = 65;
            const headerHeight = 110;
            const canvasWidth = 550;
            const canvasHeight = headerHeight + (Math.min(mutualGuilds.length, 8) * rowHeight) + 25;
            const canvas = createCanvas(canvasWidth, canvasHeight);
            const ctx = canvas.getContext('2d');
            
            // خلفية متدرجة
            drawGradientBackground(ctx, canvasWidth, canvasHeight, '#1a1d21', '#25282c');
            
            // Header مع تدرج
            const headerGradient = ctx.createLinearGradient(0, 0, 0, headerHeight);
            headerGradient.addColorStop(0, '#2c2f33');
            headerGradient.addColorStop(1, '#23272a');
            ctx.fillStyle = headerGradient;
            ctx.fillRect(0, 0, canvasWidth, headerHeight);
            
            // خط فاصل للـ header
            ctx.fillStyle = 'rgba(114, 137, 218, 0.3)';
            ctx.fillRect(0, headerHeight - 2, canvasWidth, 2);
            
            // تحميل ورسم أفتار المستخدم
            const avatarUrl = user.displayAvatarURL({ format: 'png', size: 128 });
            await drawCircularAvatar(ctx, avatarUrl, 55, 55, 32);
            
            // اسم المستخدم مع ظل
            ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
            ctx.shadowBlur = 5;
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 20px Arial';
            ctx.fillText(user.username, 105, 50);
            clearShadow(ctx);
            
            // عدد السيرفرات مع أيقونة
            ctx.fillStyle = '#b9bbbe';
            ctx.font = '14px Arial';
            ctx.fillText(`${mutualGuilds.length} سيرفر مشترك`, 105, 75);
            
            // رسم السيرفرات
            const maxServers = Math.min(mutualGuilds.length, 8);
            for (let i = 0; i < maxServers; i++) {
                const guild = mutualGuilds[i];
                const y = headerHeight + (i * rowHeight) + 12;
                
                // مربع السيرفر مع ظل
                drawShadow(ctx, 8, 'rgba(0, 0, 0, 0.3)');
                ctx.fillStyle = i % 2 === 0 ? '#2f3136' : '#36393f';
                drawRoundedRect(ctx, 15, y, canvasWidth - 30, rowHeight - 8, 8);
                ctx.fill();
                clearShadow(ctx);
                
                // أيقونة السيرفر
                if (guild.icon) {
                    try {
                        const icon = await loadImage(cleanImageUrl(guild.icon));
                        ctx.save();
                        drawShadow(ctx, 6, 'rgba(0, 0, 0, 0.4)');
                        ctx.beginPath();
                        ctx.arc(50, y + 28, 22, 0, Math.PI * 2);
                        ctx.fillStyle = '#5865f2';
                        ctx.fill();
                        clearShadow(ctx);
                        ctx.beginPath();
                        ctx.arc(50, y + 28, 22, 0, Math.PI * 2);
                        ctx.closePath();
                        ctx.clip();
                        ctx.drawImage(icon, 28, y + 6, 44, 44);
                        ctx.restore();
                        
                        // إطار للأيقونة
                        ctx.beginPath();
                        ctx.arc(50, y + 28, 22, 0, Math.PI * 2);
                        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
                        ctx.lineWidth = 2;
                        ctx.stroke();
                    } catch (e) {
                        drawShadow(ctx, 6, 'rgba(0, 0, 0, 0.4)');
                        ctx.fillStyle = '#5865f2';
                        ctx.beginPath();
                        ctx.arc(50, y + 28, 22, 0, Math.PI * 2);
                        ctx.fill();
                        clearShadow(ctx);
                        ctx.fillStyle = '#ffffff';
                        ctx.font = 'bold 18px Arial';
                        ctx.textAlign = 'center';
                        ctx.fillText(guild.name.charAt(0).toUpperCase(), 50, y + 35);
                        ctx.textAlign = 'left';
                    }
                } else {
                    drawShadow(ctx, 6, 'rgba(0, 0, 0, 0.4)');
                    ctx.fillStyle = '#5865f2';
                    ctx.beginPath();
                    ctx.arc(50, y + 28, 22, 0, Math.PI * 2);
                    ctx.fill();
                    clearShadow(ctx);
                    ctx.fillStyle = '#ffffff';
                    ctx.font = 'bold 18px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(guild.name.charAt(0).toUpperCase(), 50, y + 35);
                    ctx.textAlign = 'left';
                }
                
                // اسم السيرفر
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 15px Arial';
                let serverName = guild.name;
                if (serverName.length > 28) serverName = serverName.substring(0, 25) + '...';
                ctx.fillText(serverName, 85, y + 25);
                
                // عدد الأعضاء مع خلفية
                ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
                drawRoundedRect(ctx, 85, y + 32, 120, 20, 4);
                ctx.fill();
                
                ctx.fillStyle = '#a3a6aa';
                ctx.font = '12px Arial';
                ctx.fillText(`👥 ${guild.memberCount.toLocaleString()} عضو`, 92, y + 45);
            }
            
            // إذا في سيرفرات أكثر
            if (mutualGuilds.length > 8) {
                ctx.fillStyle = 'rgba(88, 101, 242, 0.8)';
                ctx.font = 'bold 13px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(`+${mutualGuilds.length - 8} سيرفر آخر...`, canvasWidth / 2, canvasHeight - 12);
                ctx.textAlign = 'left';
            }
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: 'mutual_servers.png' }]
            });
            
        } catch (error) {
            console.error('خطأ في البحث عن السيرفرات:', error);
            if (interaction.deferred) {
                await interaction.editReply({ content: `خطأ: ${error.message}` });
            } else {
                await interaction.reply({ content: `خطأ: ${error.message}`, ephemeral: true });
            }
        }
    }
    
    else if (interaction.customId === 'search_general_modal') {
        const searchTerm = interaction.fields.getTextInputValue('search_term').toLowerCase();
        
        if (searchTerm.length < 2) {
            return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
        }
        
        try {
            await interaction.deferReply({ ephemeral: true });
            
            let foundUsers = [];
            let searchedGuilds = 0;
            
            // البحث في سيرفرات السيلف بوت
            if (clients && clients.user) {
                console.log(`🔍 البحث عن "${searchTerm}" في ${clients.guilds.cache.size} سيرفر`);
                
                for (const guild of clients.guilds.cache.values()) {
                    searchedGuilds++;
                    try {
                        const members = await guild.members.fetch();
                        
                        for (const member of members.values()) {
                            const username = member.user.username.toLowerCase();
                            const displayName = member.displayName.toLowerCase();
                            
                            if (username.includes(searchTerm) || displayName.includes(searchTerm)) {
                                if (!foundUsers.find(u => u.id === member.user.id)) {
                                    foundUsers.push({
                                        id: member.user.id,
                                        username: member.user.username,
                                        displayName: member.displayName,
                                        avatar: member.user.displayAvatarURL({ format: 'png', size: 64 }),
                                        guild: guild.name,
                                        tag: member.user.tag
                                    });
                                }
                            }
                        }
                    } catch (error) {
                        continue;
                    }
                    
                    if (foundUsers.length >= 100) break;
                }
            }
            
            if (foundUsers.length === 0) {
                return interaction.editReply({
                    content: `لم يتم العثور على أي شخص باسم "${searchTerm}"\nتم البحث في ${searchedGuilds} سيرفر`
                });
            }
            
            // دالة لإنشاء صورة Canvas للصفحة
            async function createSearchPage(users, page, totalUsers, searchQuery, guildsCount) {
                const maxUsers = Math.min(users.length, 10);
                const rowHeight = 55;
                const headerHeight = 80;
                const canvasWidth = 500;
                const canvasHeight = headerHeight + (maxUsers * rowHeight) + 30;
                const canvas = createCanvas(canvasWidth, canvasHeight);
                const ctx = canvas.getContext('2d');
                
                ctx.fillStyle = '#2f3136';
                ctx.fillRect(0, 0, canvasWidth, canvasHeight);
                
                ctx.fillStyle = '#202225';
                ctx.fillRect(0, 0, canvasWidth, headerHeight);
                
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 18px Arial';
                ctx.fillText(`🔍 البحث عن: "${searchQuery}"`, 20, 35);
                
                ctx.fillStyle = '#b9bbbe';
                ctx.font = '14px Arial';
                const totalPages = Math.ceil(totalUsers / 10);
                ctx.fillText(`${totalUsers} نتيجة • صفحة ${page}/${totalPages} • ${guildsCount} سيرفر`, 20, 60);
                
                for (let i = 0; i < maxUsers; i++) {
                    const user = users[i];
                    const y = headerHeight + (i * rowHeight) + 5;
                    
                    ctx.fillStyle = i % 2 === 0 ? '#36393f' : '#2f3136';
                    ctx.fillRect(10, y, canvasWidth - 20, rowHeight - 5);
                    
                    try {
                        const avatar = await loadImage(cleanImageUrl(user.avatar));
                        ctx.save();
                        ctx.beginPath();
                        ctx.arc(45, y + 25, 18, 0, Math.PI * 2);
                        ctx.closePath();
                        ctx.clip();
                        ctx.drawImage(avatar, 27, y + 7, 36, 36);
                        ctx.restore();
                    } catch (e) {
                        ctx.fillStyle = '#5865f2';
                        ctx.beginPath();
                        ctx.arc(45, y + 25, 18, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.fillStyle = '#ffffff';
                        ctx.font = 'bold 14px Arial';
                        ctx.textAlign = 'center';
                        ctx.fillText(user.username.charAt(0).toUpperCase(), 45, y + 30);
                        ctx.textAlign = 'left';
                    }
                    
                    ctx.fillStyle = '#ffffff';
                    ctx.font = 'bold 14px Arial';
                    let displayName = user.displayName;
                    if (displayName.length > 20) displayName = displayName.substring(0, 17) + '...';
                    ctx.fillText(displayName, 75, y + 22);
                    
                    ctx.fillStyle = '#72767d';
                    ctx.font = '11px Arial';
                    ctx.fillText(`@${user.username}`, 75, y + 38);
                    
                    let guildName = user.guild;
                    if (guildName.length > 15) guildName = guildName.substring(0, 12) + '...';
                    ctx.fillStyle = '#5865f2';
                    ctx.fillText(`📍 ${guildName}`, 350, y + 30);
                    
                    ctx.fillStyle = '#4f545c';
                    ctx.font = '10px Arial';
                    ctx.fillText(user.id, 200, y + 38);
                }
                
                return canvas.toBuffer();
            }
            
            // حفظ النتائج للتنقل بين الصفحات
            const searchId = `search_${interaction.user.id}_${Date.now()}`;
            client.searchResults = client.searchResults || new Map();
            client.searchResults.set(searchId, {
                users: foundUsers,
                searchTerm: searchTerm,
                searchedGuilds: searchedGuilds,
                page: 1
            });
            
            // إنشاء الصفحة الأولى
            const pageUsers = foundUsers.slice(0, 10);
            const imageBuffer = await createSearchPage(pageUsers, 1, foundUsers.length, searchTerm, searchedGuilds);
            
            // إنشاء الأزرار
            const totalPages = Math.ceil(foundUsers.length / 10);
            const row = new MessageActionRow().addComponents(
                new MessageButton()
                    .setCustomId(`search_prev_${searchId}`)
                    .setLabel('◀ السابق')
                    .setStyle('SECONDARY')
                    .setDisabled(true),
                new MessageButton()
                    .setCustomId(`search_page_${searchId}`)
                    .setLabel(`1 / ${totalPages}`)
                    .setStyle('PRIMARY')
                    .setDisabled(true),
                new MessageButton()
                    .setCustomId(`search_next_${searchId}`)
                    .setLabel('التالي ▶')
                    .setStyle('SECONDARY')
                    .setDisabled(totalPages <= 1)
            );
            
            await interaction.editReply({ 
                files: [{ attachment: imageBuffer, name: 'user_search.png' }],
                components: totalPages > 1 ? [row] : []
            });
            
            // حذف النتائج بعد 5 دقائق
            setTimeout(() => {
                client.searchResults.delete(searchId);
            }, 300000);
            
        } catch (error) {
            console.error('خطأ في البحث:', error);
            if (interaction.deferred) {
                await interaction.editReply({ content: `خطأ: ${error.message}` });
            } else {
                await interaction.reply({ content: `خطأ: ${error.message}`, ephemeral: true });
            }
        }
    }
    
    // معالج أزرار التنقل في البحث
    else if (interaction.customId.startsWith('search_prev_') || interaction.customId.startsWith('search_next_')) {
        const searchId = interaction.customId.replace('search_prev_', '').replace('search_next_', '');
        const searchData = client.searchResults?.get(searchId);
        
        if (!searchData) {
            return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
        }
        
        const isNext = interaction.customId.startsWith('search_next_');
        searchData.page = isNext ? searchData.page + 1 : searchData.page - 1;
        
        const totalPages = Math.ceil(searchData.users.length / 10);
        const startIndex = (searchData.page - 1) * 10;
        const pageUsers = searchData.users.slice(startIndex, startIndex + 10);
        
        // إنشاء الصورة الجديدة
        async function createSearchPage(users, page, totalUsers, searchQuery, guildsCount) {
            const maxUsers = Math.min(users.length, 10);
            const rowHeight = 55;
            const headerHeight = 80;
            const canvasWidth = 500;
            const canvasHeight = headerHeight + (maxUsers * rowHeight) + 30;
            const canvas = createCanvas(canvasWidth, canvasHeight);
            const ctx = canvas.getContext('2d');
            
            ctx.fillStyle = '#2f3136';
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);
            
            ctx.fillStyle = '#202225';
            ctx.fillRect(0, 0, canvasWidth, headerHeight);
            
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 18px Arial';
            ctx.fillText(`🔍 البحث عن: "${searchQuery}"`, 20, 35);
            
            ctx.fillStyle = '#b9bbbe';
            ctx.font = '14px Arial';
            const pages = Math.ceil(totalUsers / 10);
            ctx.fillText(`${totalUsers} نتيجة • صفحة ${page}/${pages} • ${guildsCount} سيرفر`, 20, 60);
            
            for (let i = 0; i < maxUsers; i++) {
                const user = users[i];
                const y = headerHeight + (i * rowHeight) + 5;
                
                ctx.fillStyle = i % 2 === 0 ? '#36393f' : '#2f3136';
                ctx.fillRect(10, y, canvasWidth - 20, rowHeight - 5);
                
                try {
                    const avatar = await loadImage(cleanImageUrl(user.avatar));
                    ctx.save();
                    ctx.beginPath();
                    ctx.arc(45, y + 25, 18, 0, Math.PI * 2);
                    ctx.closePath();
                    ctx.clip();
                    ctx.drawImage(avatar, 27, y + 7, 36, 36);
                    ctx.restore();
                } catch (e) {
                    ctx.fillStyle = '#5865f2';
                    ctx.beginPath();
                    ctx.arc(45, y + 25, 18, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = '#ffffff';
                    ctx.font = 'bold 14px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(user.username.charAt(0).toUpperCase(), 45, y + 30);
                    ctx.textAlign = 'left';
                }
                
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 14px Arial';
                let displayName = user.displayName;
                if (displayName.length > 20) displayName = displayName.substring(0, 17) + '...';
                ctx.fillText(displayName, 75, y + 22);
                
                ctx.fillStyle = '#72767d';
                ctx.font = '11px Arial';
                ctx.fillText(`@${user.username}`, 75, y + 38);
                
                let guildName = user.guild;
                if (guildName.length > 15) guildName = guildName.substring(0, 12) + '...';
                ctx.fillStyle = '#5865f2';
                ctx.fillText(`📍 ${guildName}`, 350, y + 30);
                
                ctx.fillStyle = '#4f545c';
                ctx.font = '10px Arial';
                ctx.fillText(user.id, 200, y + 38);
            }
            
            return canvas.toBuffer();
        }
        
        const imageBuffer = await createSearchPage(pageUsers, searchData.page, searchData.users.length, searchData.searchTerm, searchData.searchedGuilds);
        
        const row = new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId(`search_prev_${searchId}`)
                .setLabel('◀ السابق')
                .setStyle('SECONDARY')
                .setDisabled(searchData.page <= 1),
            new MessageButton()
                .setCustomId(`search_page_${searchId}`)
                .setLabel(`${searchData.page} / ${totalPages}`)
                .setStyle('PRIMARY')
                .setDisabled(true),
            new MessageButton()
                .setCustomId(`search_next_${searchId}`)
                .setLabel('التالي ▶')
                .setStyle('SECONDARY')
                .setDisabled(searchData.page >= totalPages)
        );
        
        await interaction.update({ 
            files: [{ attachment: imageBuffer, name: 'user_search.png' }],
            components: [row]
        });
    }
    
    else if (interaction.customId === 'search_voice_modal') {
        const userId = interaction.fields.getTextInputValue('user_id');
        
        // التحقق من صحة الآيدي
        if (!/^\d{17,19}$/.test(userId)) {
            return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
        }
        
        try {
            await interaction.deferReply({ ephemeral: true });
            
            const user = await client.users.fetch(userId);
            let foundInVoice = null;
            let searchedGuilds = [];
            let voiceMembers = [];
            
            // البحث في سيرفرات السيلف بوت أولاً
            if (clients && clients.user) {
                console.log(`🔍 البحث في ${clients.guilds.cache.size} سيرفر من السيلف بوت`);
                
                for (const guild of clients.guilds.cache.values()) {
                    try {
                        const member = await guild.members.fetch(userId);
                        if (!member) continue;
                        
                        searchedGuilds.push(guild.name);
                        console.log(`وجد في سيرفر: ${guild.name}`);
                        
                        // تحقق من وجود العضو في روم صوتي
                        if (member.voice && member.voice.channel) {
                            // جمع معلومات الأعضاء في الروم
                            voiceMembers = member.voice.channel.members.map(m => ({
                                name: m.user.username,
                                avatar: m.user.displayAvatarURL({ format: 'png', size: 64 }),
                                muted: m.voice.mute || m.voice.selfMute,
                                deafened: m.voice.deaf || m.voice.selfDeaf
                            }));
                            
                            foundInVoice = {
                                guild: guild.name,
                                guildIcon: guild.iconURL({ format: 'png', size: 64 }),
                                channel: member.voice.channel.name,
                                channelId: member.voice.channel.id,
                                memberCount: member.voice.channel.members.size
                            };
                            console.log(`🔊 وجد في روم صوتي: ${member.voice.channel.name}`);
                            break;
                        }
                    } catch (error) {
                        console.log(`خطأ في البحث في ${guild.name}: ${error.message}`);
                        continue;
                    }
                }
            }
            
            // إذا لم نجده في السيلف بوت، ابحث في البوت العادي
            if (!foundInVoice) {
                console.log(`🔍 البحث في ${client.guilds.cache.size} سيرفر من البوت العادي`);
                for (const guild of client.guilds.cache.values()) {
                    const member = guild.members.cache.get(userId);
                    if (!member) continue;
                    
                    if (!searchedGuilds.includes(guild.name)) {
                        searchedGuilds.push(guild.name);
                    }
                    
                    if (member.voice && member.voice.channel) {
                        voiceMembers = member.voice.channel.members.map(m => ({
                            name: m.user.username,
                            avatar: m.user.displayAvatarURL({ format: 'png', size: 64 }),
                            muted: m.voice.mute || m.voice.selfMute,
                            deafened: m.voice.deaf || m.voice.selfDeaf
                        }));
                        
                        foundInVoice = {
                            guild: guild.name,
                            guildIcon: guild.iconURL({ format: 'png', size: 64 }),
                            channel: member.voice.channel.name,
                            channelId: member.voice.channel.id,
                            memberCount: member.voice.channel.members.size
                        };
                        break;
                    }
                }
            }
            
            // إنشاء صورة Canvas
            const canvasWidth = 450;
            const canvasHeight = foundInVoice ? 200 + (Math.min(voiceMembers.length, 5) * 50) : 200;
            const canvas = createCanvas(canvasWidth, canvasHeight);
            const ctx = canvas.getContext('2d');
            
            // خلفية Discord الداكنة
            ctx.fillStyle = '#2f3136';
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);
            
            // Header
            ctx.fillStyle = '#202225';
            ctx.fillRect(0, 0, canvasWidth, 90);
            
            // تحميل أفتار المستخدم
            const avatarUrl = user.displayAvatarURL({ format: 'png', size: 128 });
            try {
                const avatar = await loadImage(cleanImageUrl(avatarUrl));
                ctx.save();
                ctx.beginPath();
                ctx.arc(50, 45, 30, 0, Math.PI * 2);
                ctx.closePath();
                ctx.clip();
                ctx.drawImage(avatar, 20, 15, 60, 60);
                ctx.restore();
            } catch (e) {
                ctx.fillStyle = '#5865f2';
                ctx.beginPath();
                ctx.arc(50, 45, 30, 0, Math.PI * 2);
                ctx.fill();
            }
            
            // اسم المستخدم
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 18px Arial';
            ctx.fillText(user.username, 100, 40);
            
            // حالة البحث
            ctx.fillStyle = '#b9bbbe';
            ctx.font = '12px Arial';
            ctx.fillText(`تم البحث في ${searchedGuilds.length} سيرفر`, 100, 60);
            
            if (foundInVoice) {
                // مربع أخضر - موجود في روم صوتي
                ctx.fillStyle = '#3ba55d';
                ctx.fillRect(10, 100, canvasWidth - 20, 50);
                
                // أيقونة الصوت
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 16px Arial';
                ctx.fillText('🔊 موجود في روم صوتي', 20, 130);
                
                // معلومات الروم
                ctx.fillStyle = '#36393f';
                ctx.fillRect(10, 160, canvasWidth - 20, 35);
                
                ctx.fillStyle = '#ffffff';
                ctx.font = '14px Arial';
                ctx.fillText(`📍 ${foundInVoice.guild}`, 20, 182);
                
                ctx.fillStyle = '#b9bbbe';
                ctx.font = '12px Arial';
                ctx.fillText(`#${foundInVoice.channel} • ${foundInVoice.memberCount} أعضاء`, 200, 182);
                
                // عرض الأعضاء في الروم
                const maxMembers = Math.min(voiceMembers.length, 5);
                for (let i = 0; i < maxMembers; i++) {
                    const member = voiceMembers[i];
                    const y = 205 + (i * 50);
                    
                    // خلفية العضو
                    ctx.fillStyle = i % 2 === 0 ? '#36393f' : '#2f3136';
                    ctx.fillRect(10, y, canvasWidth - 20, 45);
                    
                    // أفتار العضو
                    try {
                        const memberAvatar = await loadImage(cleanImageUrl(member.avatar));
                        ctx.save();
                        ctx.beginPath();
                        ctx.arc(40, y + 22, 15, 0, Math.PI * 2);
                        ctx.closePath();
                        ctx.clip();
                        ctx.drawImage(memberAvatar, 25, y + 7, 30, 30);
                        ctx.restore();
                    } catch (e) {
                        ctx.fillStyle = '#5865f2';
                        ctx.beginPath();
                        ctx.arc(40, y + 22, 15, 0, Math.PI * 2);
                        ctx.fill();
                    }
                    
                    // اسم العضو
                    ctx.fillStyle = '#ffffff';
                    ctx.font = '14px Arial';
                    let memberName = member.name;
                    if (memberName.length > 20) memberName = memberName.substring(0, 17) + '...';
                    ctx.fillText(memberName, 65, y + 27);
                    
                    // حالة الصوت
                    ctx.fillStyle = '#72767d';
                    ctx.font = '12px Arial';
                    let status = '';
                    if (member.muted) status += '🔇 ';
                    if (member.deafened) status += '🔈 ';
                    if (!status) status = '🎤';
                    ctx.fillText(status, canvasWidth - 50, y + 27);
                }
                
                // إذا في أعضاء أكثر
                if (voiceMembers.length > 5) {
                    ctx.fillStyle = '#72767d';
                    ctx.font = '12px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(`+${voiceMembers.length - 5} عضو آخر`, canvasWidth / 2, canvasHeight - 10);
                    ctx.textAlign = 'left';
                }
            } else {
                // مربع أحمر - غير موجود
                ctx.fillStyle = '#ed4245';
                ctx.fillRect(10, 100, canvasWidth - 20, 50);
                
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 16px Arial';
                ctx.fillText('🔇 غير موجود في أي روم صوتي', 20, 130);
                
                // معلومات إضافية
                ctx.fillStyle = '#36393f';
                ctx.fillRect(10, 160, canvasWidth - 20, 35);
                
                ctx.fillStyle = '#b9bbbe';
                ctx.font = '12px Arial';
                ctx.fillText(`تم البحث في: ${searchedGuilds.slice(0, 3).join(', ')}${searchedGuilds.length > 3 ? '...' : ''}`, 20, 182);
            }
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: 'voice_search.png' }]
            });
            
        } catch (error) {
            console.error('خطأ في البحث في الرومات الصوتية:', error);
            if (interaction.deferred) {
                await interaction.editReply({ content: `خطأ: ${error.message}` });
            } else {
                await interaction.reply({ content: `خطأ: ${error.message}`, ephemeral: true });
            }
        }
    }
    
    // Image editing modals
    else if (interaction.customId === 'blur_modal') {
        const url = interaction.fields.getTextInputValue('blur_url');
        
        // التحقق من صحة الرابط
        if (!url || !url.startsWith('http')) {
            return interaction.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }
        
        // التحقق من نوع الصورة
        if (url.includes('.webp') || url.includes('.gif')) {
            return interaction.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }
        
        await interaction.reply({ ephemeral: true, content: `⏳ يرجى الانتظار...` });
        
        try {
            const img = await loadImageFromUrl(url);
            
            const canvas = createCanvas(img.width, img.height);
            const ctx = canvas.getContext('2d');
            
            // تطبيق تأثير blur بسيط
            ctx.filter = 'blur(5px)';
            ctx.drawImage(img, 0, 0);
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: "blurred.png" }], 
                content: `تم تطبيق التأثير` 
            });
        } catch (err) {
            console.error('خطأ في blur:', err);
            await interaction.editReply({ 
                content: `❌ فشل في معالجة الصورة.\nتأكد من:\n• الرابط صحيح\n• الصورة بصيغة PNG أو JPG\n• الرابط مباشر للصورة` 
            });
        }
    }
    
    else if (interaction.customId === 'darkness_modal') {
        const url = interaction.fields.getTextInputValue('darkness_url');
        
        // التحقق من صحة الرابط
        if (!url || !url.startsWith('http')) {
            return interaction.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }
        
        if (url.includes('.webp') || url.includes('.gif')) {
            return interaction.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }
        
        await interaction.reply({ ephemeral: true, content: `⏳ يرجى الانتظار...` });
        
        try {
            const img = await loadImageFromUrl(url);
            
            const canvas = createCanvas(img.width, img.height);
            const ctx = canvas.getContext('2d');
            
            ctx.drawImage(img, 0, 0);
            // تطبيق تأثير الظلام
            ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: "darkness.png" }], 
                content: `تم تطبيق التأثير` 
            });
        } catch (err) {
            console.error('خطأ في darkness:', err);
            await interaction.editReply({ 
                content: `❌ فشل في معالجة الصورة.\nتأكد من:\n• الرابط صحيح\n• الصورة بصيغة PNG أو JPG\n• الرابط مباشر للصورة` 
            });
        }
    }
    
    else if (interaction.customId === 'circle_modal') {
        const url = interaction.fields.getTextInputValue('circle_url');
        
        // التحقق من صحة الرابط
        if (!url || !url.startsWith('http')) {
            return interaction.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }
        
        await interaction.reply({ ephemeral: true, content: `⏳ يرجى الانتظار...` });
        
        try {
            const img = await loadImageFromUrl(url);
            
            const size = Math.min(img.width, img.height);
            const canvas = createCanvas(size, size);
            const ctx = canvas.getContext('2d');
            
            // قص دائري
            ctx.beginPath();
            ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
            ctx.closePath();
            ctx.clip();

/*
 * [KSHK / CONTROL SUITE]
 * Source ownership: KSHK Store
 * Community: discord.gg/kshk
 * © 2026 KSHK Store — protected source
 */

            
            ctx.drawImage(img, (img.width - size) / -2, (img.height - size) / -2);
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: "circle.png" }], 
                content: `تم قص الصورة` 
            });
        } catch (err) {
            console.error('خطأ في circle:', err);
            await interaction.editReply({ 
                content: `❌ فشل في معالجة الصورة.\nتأكد من:\n• الرابط صحيح\n• الصورة بصيغة PNG أو JPG\n• الرابط مباشر للصورة` 
            });
        }
    }
    
    else if (interaction.customId === 'sepia_modal') {
        const url = interaction.fields.getTextInputValue('sepia_url');
        
        // التحقق من صحة الرابط
        if (!url || !url.startsWith('http')) {
            return interaction.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }

/* ── KSHK SOURCE MARK ─────────────────────────────────────────────
 * KSHK Store · discord.gg/kshk · © 2026
 * Protected component of the KSHK Control Suite.
 * ───────────────────────────────────────────────────────────────── */

        
        await interaction.reply({ ephemeral: true, content: `⏳ يرجى الانتظار...` });
        
        try {
            const img = await loadImageFromUrl(url);
            
            const canvas = createCanvas(img.width, img.height);
            const ctx = canvas.getContext('2d');
            
            ctx.drawImage(img, 0, 0);
            
            // تطبيق تأثير sepia
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const data = imageData.data;
            
            for (let i = 0; i < data.length; i += 4) {
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];
                
                data[i] = Math.min(255, (r * 0.393) + (g * 0.769) + (b * 0.189));
                data[i + 1] = Math.min(255, (r * 0.349) + (g * 0.686) + (b * 0.168));
                data[i + 2] = Math.min(255, (r * 0.272) + (g * 0.534) + (b * 0.131));
            }
            
            ctx.putImageData(imageData, 0, 0);
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: "sepia.png" }], 
                content: `تم تطبيق التأثير` 
            });
        } catch (err) {
            console.error('خطأ في sepia:', err);
            await interaction.editReply({ 
                content: `❌ فشل في معالجة الصورة.\nتأكد من:\n• الرابط صحيح\n• الصورة بصيغة PNG أو JPG\n• الرابط مباشر للصورة` 
            });
        }
    }
    
    else if (interaction.customId === 'invert_modal') {
        const url = interaction.fields.getTextInputValue('invert_url');
        
        // التحقق من صحة الرابط
        if (!url || !url.startsWith('http')) {
            return interaction.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }
        
        await interaction.reply({ ephemeral: true, content: `⏳ يرجى الانتظار...` });
        
        try {
            const img = await loadImageFromUrl(url);
            
            const canvas = createCanvas(img.width, img.height);
            const ctx = canvas.getContext('2d');
            
            ctx.drawImage(img, 0, 0);
            
            // تطبيق تأثير invert
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const data = imageData.data;
            
            for (let i = 0; i < data.length; i += 4) {
                data[i] = 255 - data[i];         // R
                data[i + 1] = 255 - data[i + 1]; // G
                data[i + 2] = 255 - data[i + 2]; // B
            }
            
            ctx.putImageData(imageData, 0, 0);
            
            await interaction.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: "inverted.png" }], 
                content: `تم عكس الالوان` 
            });
        } catch (err) {
            console.error('خطأ في invert:', err);
            await interaction.editReply({ 
                content: `❌ فشل في معالجة الصورة.\nتأكد من:\n• الرابط صحيح\n• الصورة بصيغة PNG أو JPG\n• الرابط مباشر للصورة` 
            });
        }
    }
    
    // معالج Modal لتعيين قناة النشر
    else if (interaction.customId === 'set_channel_modal') {
        const channelInput = interaction.fields.getTextInputValue('channel_id');
        
        if (!config.owners.includes(interaction.user.id) && !interaction.member.permissions.has('ADMINISTRATOR')) {
            return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
        }
        
        let channel;
        
        // التحقق إذا كان منشن أو آيدي
        if (channelInput.startsWith('<#') && channelInput.endsWith('>')) {
            const channelId = channelInput.slice(2, -1);
            channel = interaction.guild.channels.cache.get(channelId);
        } else if (/^\d{17,19}$/.test(channelInput)) {
            channel = interaction.guild.channels.cache.get(channelInput);
        } else {
            return interaction.reply({ 
                content: '❌ يرجى إدخال آيدي القناة أو منشن القناة بشكل صحيح\n`#channel` أو `123456789`', 
                ephemeral: true 
            });
        }
        
        if (!channel) {
            return interaction.reply({ 
                content: 'لم يتم تفعيل الامر من قبل المالك', 
                ephemeral: true 
            });
        }

        if (channel.type !== 'GUILD_TEXT') {
            return interaction.reply({ 
                content: 'لم يتم تفعيل الامر من قبل المالك', 
                ephemeral: true 
            });
        }

        // حفظ القناة في قاعدة البيانات
        Pro.set(`server_${interaction.guild.id}`, channel.id);
        
        await interaction.reply({ 
            content: `✅ تم تعيين قناة النشر:\n<#${channel.id}>`, 
            ephemeral: true 
        });
    }
});

const userInputs = new Map();
client.on('interactionCreate', async interaction => {
    if (interaction.isSelectMenu()) {

        // Function لإعادة تعيين القوائم
        async function resetMenus() {
            try {
                await interaction.message.edit({ components: interaction.message.components });
            } catch (e) {}
        }

        // معالج قائمة الشارات
        if (interaction.customId === 'badge_menu') {
            const selectedOption = interaction.values[0];
            
            switch (selectedOption) {
                case 'nitro':
                    const nitroModal = new Modal()
                        .setCustomId('nitro_modal')
                        .setTitle('فحص شارة النيترو');
                    
                    const nitroUserInput = new TextInputComponent()
                        .setCustomId('nitro_user_id')
                        .setLabel('آيدي الشخص (اتركه فارغ لفحص نفسك)')
                        .setStyle('SHORT')
                        .setPlaceholder('مثال: 123456789012345678')
                        .setRequired(false);
                    
                    const nitroRow = new MessageActionRow().addComponents(nitroUserInput);
                    nitroModal.addComponents(nitroRow);
                    
                    await interaction.showModal(nitroModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'boost':
                    const boostModal = new Modal()
                        .setCustomId('boost_modal')
                        .setTitle('فحص شارة البوست');
                    
                    const boostUserInput = new TextInputComponent()
                        .setCustomId('boost_user_id')
                        .setLabel('آيدي الشخص (اتركه فارغ لفحص نفسك)')
                        .setStyle('SHORT')
                        .setPlaceholder('مثال: 123456789012345678')
                        .setRequired(false);
                    
                    const boostRow = new MessageActionRow().addComponents(boostUserInput);
                    boostModal.addComponents(boostRow);
                    
                    await interaction.showModal(boostModal);
                    setTimeout(resetMenus, 500);
                    break;
            }
        }
        // معالج قائمة النشر
        else if (interaction.customId === 'publish_menu') {
            const selectedOption = interaction.values[0];
            
            switch (selectedOption) {
                case 'publish_server':
                    // التحقق من الكولداون قبل فتح الـ Modal من قاعدة البيانات
                    const serverCooldown = checkCooldown(interaction.user.id);
                    if (serverCooldown > 0) {
                        await interaction.reply({ 
                            content: `انتظر ${formatCooldownTime(serverCooldown)} قبل ما تنشر مرة ثانية`,
                            ephemeral: true 
                        });
                        setTimeout(resetMenus, 500);
                        break;
                    }
                    
                    const publishServerModal = new Modal()
                        .setCustomId('publish_server_modal')
                        .setTitle('نشر السيرفر');
                    
                    const serverLink = new TextInputComponent()
                        .setCustomId('server_link')
                        .setLabel('رابط السيرفر | Server Link')
                        .setStyle('SHORT')
                        .setPlaceholder('https://discord.gg/...')
                        .setRequired(true);
                    
                    const serverRow1 = new MessageActionRow().addComponents(serverLink);
                    publishServerModal.addComponents(serverRow1);
                    await interaction.showModal(publishServerModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'publish_avatar':
                    // التحقق من الكولداون قبل فتح الـ Modal من قاعدة البيانات
                    const avatarCooldown = checkCooldown(interaction.user.id);
                    if (avatarCooldown > 0) {
                        await interaction.reply({ 
                            content: `انتظر ${formatCooldownTime(avatarCooldown)} قبل ما تنشر مرة ثانية`,
                            ephemeral: true 
                        });
                        setTimeout(resetMenus, 500);
                        break;
                    }
                    
                    const publishAvatarModal = new Modal()
                        .setCustomId('publish_avatar_modal')
                        .setTitle('نشر الافتار');
                    
                    const avatarLink = new TextInputComponent()
                        .setCustomId('avatar_link')
                        .setLabel('رابط الافتار | Avatar Link')
                        .setStyle('SHORT')
                        .setPlaceholder('https://discord.gg/...')
                        .setRequired(true);
                    
                    const avatarRow1 = new MessageActionRow().addComponents(avatarLink);
                    publishAvatarModal.addComponents(avatarRow1);
                    await interaction.showModal(publishAvatarModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'publish_store':
                    // التحقق من الكولداون قبل فتح الـ Modal من قاعدة البيانات
                    const storeCooldown = checkCooldown(interaction.user.id);
                    if (storeCooldown > 0) {
                        await interaction.reply({ 
                            content: `انتظر ${formatCooldownTime(storeCooldown)} قبل ما تنشر مرة ثانية`,
                            ephemeral: true 
                        });
                        setTimeout(resetMenus, 500);
                        break;
                    }
                    
                    const publishStoreModal = new Modal()
                        .setCustomId('publish_store_modal')
                        .setTitle('نشر المتجر');
                    
                    const storeLink = new TextInputComponent()
                        .setCustomId('store_link')
                        .setLabel('رابط المتجر | Store Link')
                        .setStyle('SHORT')
                        .setPlaceholder('https://discord.gg/...')
                        .setRequired(true);
                    
                    const storeRow1 = new MessageActionRow().addComponents(storeLink);
                    publishStoreModal.addComponents(storeRow1);
                    await interaction.showModal(publishStoreModal);
                    setTimeout(resetMenus, 500);
                    break;
            }
        }

        // معالج قائمة التحميل
        else if (interaction.customId === 'download_menu') {
            const selectedOption = interaction.values[0];
            
            const Moad = new Modal()
                .setCustomId(`Downolad`)
                .setTitle(`تحميل الوسائط`);
            
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("يرجى وضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
            setTimeout(resetMenus, 500);
        }

        // معالج قائمة التعديل
        else if (interaction.customId === 'edit_menu') {
            const selectedOption = interaction.values[0];
            
            switch (selectedOption) {
                case 'avatar':
                    const modal1 = new Modal()
                        .setTitle('Write User ID')
                        .setCustomId('av-banner');

                    const userIdInput = new TextInputComponent()
                        .setCustomId('user_id')
                        .setLabel('يرجى وضع ايدي الشخص')
                        .setStyle('SHORT');

                    const actionRow = new MessageActionRow().addComponents(userIdInput);
                    modal1.addComponents(actionRow);
                    await interaction?.showModal(modal1);
                    setTimeout(resetMenus, 500);
                    break;

                case 'wb':
                    const modal2 = new Modal()
                        .setTitle("From colored to colorless")
                        .setCustomId("wb_modal")

                    const imgurl = new TextInputComponent()
                        .setCustomId("imgurl")
                        .setLabel("يرجى وضع رابط الصورة")
                        .setStyle('SHORT')

                    const b = new MessageActionRow().addComponents(imgurl)
                    modal2.addComponents(b)
                    await interaction.showModal(modal2)
                    setTimeout(resetMenus, 500);
                    break;

                case 'bg':
                    const modal4 = new Modal()
                        .setTitle("Background Remover")
                        .setCustomId("bg_modal")

                    const text = new TextInputComponent()
                        .setCustomId("bg_urll")
                        .setLabel("ضع رابط الخلفية")
                        .setStyle('SHORT')

                    const l1 = new MessageActionRow().addComponents(text)
                    modal4.addComponents(l1)
                    await interaction.showModal(modal4)
                    setTimeout(resetMenus, 500);
                    break;

                case 'blur':
                    const blurModal = new Modal()
                        .setTitle("Blur Effect")
                        .setCustomId("blur_modal");
                    
                    const blurUrl = new TextInputComponent()
                        .setCustomId("blur_url")
                        .setLabel("يرجى وضع رابط الصورة")
                        .setStyle('SHORT');
                    
                    const blurRow = new MessageActionRow().addComponents(blurUrl);
                    blurModal.addComponents(blurRow);
                    await interaction.showModal(blurModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'darkness':
                    const darknessModal = new Modal()
                        .setTitle("Darkness Effect")
                        .setCustomId("darkness_modal");
                    
                    const darknessUrl = new TextInputComponent()
                        .setCustomId("darkness_url")
                        .setLabel("يرجى وضع رابط الصورة")
                        .setStyle('SHORT');
                    
                    const darknessRow = new MessageActionRow().addComponents(darknessUrl);
                    darknessModal.addComponents(darknessRow);
                    await interaction.showModal(darknessModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'circle':
                    const circleModal = new Modal()
                        .setTitle("Circle Effect")
                        .setCustomId("circle_modal");
                    
                    const circleUrl = new TextInputComponent()
                        .setCustomId("circle_url")
                        .setLabel("يرجى وضع رابط الصورة")
                        .setStyle('SHORT');
                    
                    const circleRow = new MessageActionRow().addComponents(circleUrl);
                    circleModal.addComponents(circleRow);
                    await interaction.showModal(circleModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'sepia':
                    const sepiaModal = new Modal()
                        .setTitle("Sepia Effect")
                        .setCustomId("sepia_modal");
                    
                    const sepiaUrl = new TextInputComponent()
                        .setCustomId("sepia_url")
                        .setLabel("يرجى وضع رابط الصورة")
                        .setStyle('SHORT');
                    
                    const sepiaRow = new MessageActionRow().addComponents(sepiaUrl);
                    sepiaModal.addComponents(sepiaRow);
                    await interaction.showModal(sepiaModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'invert':
                    const invertModal = new Modal()
                        .setTitle("Invert Colors")
                        .setCustomId("invert_modal");
                    
                    const invertUrl = new TextInputComponent()
                        .setCustomId("invert_url")
                        .setLabel("يرجى وضع رابط الصورة")
                        .setStyle('SHORT');
                    
                    const invertRow = new MessageActionRow().addComponents(invertUrl);
                    invertModal.addComponents(invertRow);
                    await interaction.showModal(invertModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'ai_image':
                    const aiModal = new Modal()
                        .setCustomId("ai_modal")
                        .setTitle("AI Generator");

                    const aiPrompt = new TextInputComponent()
                        .setCustomId("prompat")
                        .setLabel("اكتب اي شي في بالك وبيتحول الى صورة")
                        .setStyle('SHORT')
                        .setRequired(true);

                    const aiRow = new MessageActionRow().addComponents(aiPrompt);
                    aiModal.addComponents(aiRow);
                    await interaction.showModal(aiModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'create_banner':
                    const bannerModal = new Modal()
                        .setCustomId('createimage')
                        .setTitle('Create Banner');

                    const bannerText = new TextInputComponent()
                        .setCustomId('textInputCustomId')
                        .setLabel('ضع الكلام هنا')
                        .setStyle('SHORT')
                        .setMaxLength(50)
                        .setRequired(true);

                    const bannerUrl = new TextInputComponent()
                        .setCustomId('urlInputCustomId')
                        .setLabel('Insert Image URL')
                        .setStyle('SHORT')
                        .setRequired(true);

                    const bannerRow1 = new MessageActionRow().addComponents(bannerText);
                    const bannerRow2 = new MessageActionRow().addComponents(bannerUrl);
                    bannerModal.addComponents(bannerRow1, bannerRow2);
                    await interaction.showModal(bannerModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'create_gif':
                    const gifModal = new Modal()
                        .setCustomId('createtext')
                        .setTitle('Create Banner text');

                    const gifText = new TextInputComponent()
                        .setCustomId('textInputCustomId')
                        .setLabel('ضع الكلام هنا')
                        .setStyle('SHORT')
                        .setMaxLength(50)
                        .setRequired(true);

                    const gifImage = new TextInputComponent()
                        .setCustomId('imageurl')
                        .setLabel('يرجى وضع رابط الصورة')
                        .setStyle('SHORT')
                        .setRequired(false);

                    const gifRow1 = new MessageActionRow().addComponents(gifText);
                    const gifRow2 = new MessageActionRow().addComponents(gifImage);
                    gifModal.addComponents(gifRow1, gifRow2);
                    await interaction.showModal(gifModal);
                    setTimeout(resetMenus, 500);
                    break;
            }
        }

        // معالج قائمة البحث
        else if (interaction.customId === 'search_menu') {
            const selectedOption = interaction.values[0];
            
            switch (selectedOption) {
                case 'search_message':
                    const searchMessageModal = new Modal()
                        .setCustomId('search_message_modal')
                        .setTitle('البحث عن آخر رسالة');
                    
                    const messageUserId = new TextInputComponent()
                        .setCustomId('user_id')
                        .setLabel('ايدي الشخص')
                        .setStyle('SHORT')
                        .setPlaceholder('123456789...')
                        .setRequired(true);
                    
                    const messageRow = new MessageActionRow().addComponents(messageUserId);
                    searchMessageModal.addComponents(messageRow);
                    await interaction.showModal(searchMessageModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'search_server':
                    const searchServerModal = new Modal()
                        .setCustomId('search_server_modal')
                        .setTitle('عرض السيرفرات المشتركة');
                    
                    const serverUserId = new TextInputComponent()
                        .setCustomId('user_id')
                        .setLabel('ايدي الشخص')
                        .setStyle('SHORT')
                        .setPlaceholder('123456789...')
                        .setRequired(true);
                    
                    const serverRow = new MessageActionRow().addComponents(serverUserId);
                    searchServerModal.addComponents(serverRow);
                    await interaction.showModal(searchServerModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'search_general':
                    const searchGeneralModal = new Modal()
                        .setCustomId('search_general_modal')
                        .setTitle('البحث عن شخص');
                    
                    const searchTerm = new TextInputComponent()
                        .setCustomId('search_term')
                        .setLabel('اسم الشخص أو جزء منه')
                        .setStyle('SHORT')
                        .setPlaceholder('مثال: Ahmed أو ahm')
                        .setRequired(true);
                    
                    const generalRow = new MessageActionRow().addComponents(searchTerm);
                    searchGeneralModal.addComponents(generalRow);
                    await interaction.showModal(searchGeneralModal);
                    setTimeout(resetMenus, 500);
                    break;

                case 'search_voice':
                    const searchVoiceModal = new Modal()
                        .setCustomId('search_voice_modal')
                        .setTitle('البحث في الرومات الصوتية');
                    
                    const voiceUserId = new TextInputComponent()
                        .setCustomId('user_id')
                        .setLabel('ايدي الشخص')
                        .setStyle('SHORT')
                        .setPlaceholder('123456789...')
                        .setRequired(true);
                    
                    const voiceRow = new MessageActionRow().addComponents(voiceUserId);
                    searchVoiceModal.addComponents(voiceRow);
                    await interaction.showModal(searchVoiceModal);
                    setTimeout(resetMenus, 500);
                    break;
            }
        }


/* ── KSHK SOURCE MARK ─────────────────────────────────────────────
 * KSHK Store · discord.gg/kshk · © 2026
 * Protected component of the KSHK Control Suite.
 * ───────────────────────────────────────────────────────────────── */


        // الكود القديم للقائمة الموحدة (للتوافق مع الإصدارات السابقة)
        if (interaction.customId === 'setup_select_menu') {
            const selectedOption = interaction.values[0];

            switch (selectedOption) {
                case 'Downolad':
                    const Moad = new Modal().setCustomId(`Downolad`).setTitle(`Downloader`)
                    const Service_1 = new TextInputComponent().setCustomId('Downolads').setLabel("يرجى وضع الرابط هنا").setStyle('SHORT').setPlaceholder(' ').setRequired(true).setMinLength(1);
                    const Service1 = new MessageActionRow().addComponents(Service_1);
                    Moad.addComponents(Service1);
                    interaction.showModal(Moad);
                    break;

                case 'createe':
                    const modal = new Modal()
                        .setCustomId('createimage')
                        .setTitle('Create Banner');

                    const nameInput = new TextInputComponent()
                        .setCustomId('textInputCustomId')
                        .setLabel('ضع الكلام هنا')
                        .setStyle('SHORT')
                        .setMaxLength(50)
                        .setRequired(true);

                    const urlInput = new TextInputComponent()
                        .setCustomId('urlInputCustomId')
                        .setLabel('Insert Image URL')
                        .setStyle('SHORT')
                        .setRequired(true);

                    const nameRow = new MessageActionRow().addComponents(nameInput);
                    const urlRow = new MessageActionRow().addComponents(urlInput);
                    modal.addComponents(nameRow, urlRow);
                    interaction.showModal(modal);
                    break;

                case 'create_text':
                    const modal23 = new Modal()
                        .setCustomId('createtext')
                        .setTitle('Create Banner text');

                    const nameInput1 = new TextInputComponent()
                        .setCustomId('textInputCustomId')
                        .setLabel('ضع الكلام هنا')
                        .setStyle('SHORT')
                        .setMaxLength(50)
                        .setRequired(true);

                    const imageInput = new TextInputComponent()
                        .setCustomId('imageurl')
                        .setLabel('يرجى وضع رابط الصورة')
                        .setStyle('SHORT')
                        .setRequired(false);

                    const nameRow1 = new MessageActionRow().addComponents(nameInput1);
                    const urlRow1 = new MessageActionRow().addComponents(imageInput);
                    modal23.addComponents(nameRow1, urlRow1);
                    interaction.showModal(modal23);
                    break;
            }
        }
    }
});



client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("ضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "ai") {
        const modal = new Modal()
            .setCustomId("ai_modal")
            .setTitle("AI Chat");
        
        const questionInput = new TextInputComponent()
            .setCustomId("ai_question")
            .setLabel("اكتب سؤالك")
            .setStyle("PARAGRAPH")
            .setRequired(true);
        
        const row = new MessageActionRow().addComponents(questionInput);
        modal.addComponents(row);
        await interaction.showModal(modal);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("ضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("ضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "ai") {
        const modal = new Modal()
            .setCustomId("ai_modal")
            .setTitle("AI Chat");
        
        const questionInput = new TextInputComponent()
            .setCustomId("ai_question")
            .setLabel("اكتب سؤالك")
            .setStyle("PARAGRAPH")
            .setRequired(true);
        
        const row = new MessageActionRow().addComponents(questionInput);
        modal.addComponents(row);
        await interaction.showModal(modal);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("ضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "ai") {
        const modal = new Modal()
            .setCustomId("ai_modal")
            .setTitle("AI Generator");

        const prompat = new TextInputComponent()
            .setCustomId("prompat")
            .setLabel("اكتب اي شي في بالك وبيتحول الى صورة")
            .setStyle('SHORT');

        const row = new MessageActionRow().addComponents(prompat);
        modal.addComponents(row);
        await interaction.showModal(modal);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("ضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "ai") {
        const modal = new Modal()
            .setCustomId("ai_modal")
            .setTitle("AI Generator");

        const prompat = new TextInputComponent()
            .setCustomId("prompat")
            .setLabel("اكتب اي شي في بالك وبيتحول الى صورة")
            .setStyle('SHORT');

        const row = new MessageActionRow().addComponents(prompat);
        modal.addComponents(row);
        await interaction.showModal(modal);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("ضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("ضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

// معالج زر AI Generator - لفتح نافذة إدخال النص لتحويله لصورة
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "ai") {
        const modal = new Modal()
            .setCustomId("ai_modal")
            .setTitle("AI Generator");

        const prompat = new TextInputComponent()
            .setCustomId("prompat")
            .setLabel("اكتب اي شي في بالك وبيتحول الى صورة")
            .setStyle('SHORT');

        const row = new MessageActionRow().addComponents(prompat);
        modal.addComponents(row);
        await interaction.showModal(modal);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "Downolad") {

            const Moad = new Modal().setCustomId("Downolad").setTitle("Downloader");
            const Service_1 = new TextInputComponent()
                .setCustomId('Downolads')
                .setLabel("يرجى وضع الرابط هنا")
                .setStyle('SHORT')
                .setPlaceholder(' ')
                .setRequired(true)
                .setMinLength(1);
            const Service1 = new MessageActionRow().addComponents(Service_1);
            Moad.addComponents(Service1);
            await interaction.showModal(Moad);
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "ai") {
        const modal = new Modal()
            .setCustomId("ai_modal")
            .setTitle("AI Generator");

        const prompat = new TextInputComponent()
            .setCustomId("prompat")
            .setLabel("اكتب اي شي في بالك وبيتحول الى صورة")
            .setStyle('SHORT');

        const l = new MessageActionRow().addComponents(prompat);
        modal.addComponents(l);
        await interaction.showModal(modal);
    }
});


client.on("interactionCreate", async i => {
    if (i.isModalSubmit()) {
        if (i.customId === "ai_modal") {
            // التحقق من وجود مفتاح OpenAI صحيح
            if (!config.openaiKey || config.openaiKey.includes('ضع_مفتاح') || config.openaiKey.length < 20) {
                return i.reply({ 
                    content: '❌ مفتاح OpenAI API غير مُعد\n\nللحصول على مفتاح:\n1. اذهب إلى https://platform.openai.com/api-keys\n2. أنشئ مفتاح جديد\n3. ضعه في ملف `runtime.settings.js` في خانة `openaiKey`', 
                    ephemeral: true 
                });
            }
            
            try {
                await i.deferReply({ ephemeral: true });
                
                const prompat = i.fields.getTextInputValue("prompat");
                const englishPrompat = await translate(prompat, null, "en");
                
                const response = await openai.images.generate({ 
                    prompt: englishPrompat.translation, 
                    size: "1024x1024", 
                    n: 1, 
                    quality: "hd" 
                });
                
                const url = response.data[0].url;
                const embed = new MessageEmbed()
                    .setTitle("Generated Image")
                    .setDescription(`Prompt: ${prompat}`)
                    .setImage(url)
                    .setColor('#FF0000');
                    
                let row = new MessageActionRow().addComponents(
                    new MessageButton()
                        .setStyle('LINK')
                        .setLabel("Download")
                        .setURL(url)
                );
                
                await i.editReply({ embeds: [embed], components: [row] });
            } catch (err) {
                console.error('خطأ في AI Generator:', err);
                
                let errorMessage = '❌ فشل في إنشاء الصورة';
                if (err.message && (err.message.includes('API key') || err.message.includes('401') || err.message.includes('Unauthorized'))) {
                    errorMessage = '❌ مفتاح OpenAI API غير صحيح أو منتهي الصلاحية\n\nللحصول على مفتاح:\n1. اذهب إلى https://platform.openai.com/api-keys\n2. أنشئ مفتاح جديد\n3. ضعه في ملف `runtime.settings.js`';
                } else if (err.message && err.message.includes('rate limit')) {
                    errorMessage = '❌ تم تجاوز الحد المسموح. حاول لاحقاً';
                } else if (err.message && err.message.includes('billing')) {
                    errorMessage = '❌ حساب OpenAI يحتاج رصيد. أضف رصيد من لوحة التحكم';
                } else if (err.cause && err.cause.message && err.cause.message.includes('not a legal HTTP header')) {
                    errorMessage = '❌ مفتاح OpenAI API غير صحيح\n\nللحصول على مفتاح:\n1. اذهب إلى https://platform.openai.com/api-keys\n2. أنشئ مفتاح جديد\n3. ضعه في ملف `runtime.settings.js`';
                }
                
                if (i.deferred) {
                    await i.editReply({ content: errorMessage });
                } else {
                    await i.reply({ content: errorMessage, ephemeral: true });
                }
            }
        }
    }
})


// دالة إنشاء صور GIF متحركة مع نص وتأثيرات حركية
async function createAnimatedGIF(text, font, movement, frameIndex, imageUrl) {
    const canvas = createCanvas(480, 168);
    const ctx = canvas.getContext('2d');

    // تحميل الصورة على الـ Canvas
    const img = await loadImageFromUrl(imageUrl);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    // رسم النص
    ctx.fillStyle = '#fff';
    ctx.font = '32px ' + font;
    const textWidth = ctx.measureText(text).width;
    const x = (canvas.width - textWidth) / 2;
    const y = canvas.height / 2;

    // تطبيق تأثير الحركة المختار
    switch (movement) {
        case 'slide': // تأثير الانزلاق
            ctx.fillText(text, x + frameIndex * 10, y);
            break;
        case 'bounce': // تأثير الارتداد
            ctx.fillText(text, x + Math.sin(frameIndex) * 10, y);
            break;
        case 'glitch': // تأثير الخلل
            ctx.fillStyle = '#fff';
            ctx.fillText(text, x + Math.sin(frameIndex) * 10, y);
            ctx.globalCompositeOperation = 'difference';
            ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
            ctx.fillText(text, x, y);
            ctx.globalCompositeOperation = 'source-over';
            break;
        default: // بدون تأثير
            ctx.fillText(text, x, y);
            break;
    }

    return canvas;
}



client.on('interactionCreate', async interaction => {
    if (interaction.isModalSubmit()) {


        if (interaction.customId === 'createtext') {
            const text = interaction?.fields.getTextInputValue('textInputCustomId'); // النص المُدخل
            const image = cleanImageUrl(interaction?.fields.getTextInputValue('imageurl')); // الرابط المُدخل
            
            // التحقق من الرابط
            if (!image || !image.startsWith('http')) {
                return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
            }
            
            // بناء قائمة لاختيار نوع الحركة
            const motionOptions = ['slide', 'bounce', 'glitch'].map(motion => ({
                label: motion,
                value: motion,
                description: `Choose ${motion} motion`
            }));

            const selectMenuMotion = new MessageSelectMenu()
                .setCustomId('selectMotion')
                .setPlaceholder("اختار الحركه")
                .addOptions(motionOptions);

            // الرد على التفاعل بطلب اختيار نوع الحركة
            await interaction.reply({ components: [new MessageActionRow().addComponents(selectMenuMotion)], ephemeral: true });


            try {
                // انتظر اختيار النوع من الحركة
                const motioninteraction = await interaction.channel.awaitMessageComponent({ filter: i => i.user.id === interaction.user.id && i.customId === 'selectMotion', time: 60000 });

                await interaction.editReply({ content: "⏳ جاري إنشاء الصورة المتحركة...", components: [] });
                
                // إنشاء الصورة المتحركة بعد تحديد نوع الحركة
                const encoder = new GIFEncoder(480, 168);
                const frames = [];
                for (let i = 0; i < 10; i++) {
                    const frame = await createAnimatedGIF(text, 'Arial', motioninteraction.values[0], i, image);
                    frames.push(frame);
                }

                encoder.start();
                encoder.setRepeat(0); // تكرار غير محدود
                encoder.setDelay(100); // تأخير 100 ميلي ثانية بين الإطارات
                for (const frame of frames) {
                    encoder.addFrame(frame.getContext('2d'));
                }
                encoder.finish();

                const attachment = new Discord.MessageAttachment(encoder.out.getData(), text + '.gif');

                // تحديث الرسالة الأصلية بإرفاق الصورة المتحركة وتغيير نص الرسالة
                await interaction.editReply({
                    content: 'تم انشاء الصورة',
                    components: [],
                    files: [attachment]
                });
            } catch (err) {
                console.error('خطأ في إنشاء GIF:', err);
                try {
                    await interaction.editReply({
                        content: '❌ فشل في إنشاء الصورة المتحركة\nتأكد من:\n• الرابط صحيح ومباشر للصورة\n• الصورة بصيغة PNG أو JPG',
                        components: []
                    });
                } catch (e) {
                    // تجاهل إذا فشل التعديل
                }
            }
        } else if (interaction.customId === 'createimage') {
            const text = interaction?.fields.getTextInputValue('textInputCustomId'); // Retrieve the entered text
            const imageUrl = cleanImageUrl(interaction?.fields.getTextInputValue('urlInputCustomId')); // Retrieve the entered URL
            
            // التحقق من الرابط
            if (!imageUrl || !imageUrl.startsWith('http')) {
                return interaction.reply({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
            }
            
            userInputs.set(interaction?.user.id, { text, imageUrl }); // Store both text and URL

            const fontSizeOptions = ['20', '30', '40', '50', '60'].map(size => ({
                label: `${size}px`,
                value: size,
                description: `Set font size to ${size}px`
            }));

            const selectMenuFontSize = new MessageSelectMenu()
                .setCustomId('selectFontSize')
                .setPlaceholder('Select a font size')
                .addOptions(fontSizeOptions);

            await interaction?.reply({ content: 'Select font size:', components: [new MessageActionRow().addComponents(selectMenuFontSize)], ephemeral: true });
        }
    }
    
    // معالج قوائم اختيار البانر
    if (interaction?.isSelectMenu()) {
        if (interaction.customId === 'selectFontSize') {
            const fontSize = interaction?.values[0];
            userInputs.set(interaction?.user.id, { ...userInputs.get(interaction?.user.id), fontSize });

            const textColorOptions = ['black', 'white', 'purple', 'blue', 'red', 'brown'].map(color => ({
                label: getArabicColorName(color),
                value: color,
                description: `Set text color to ${color}`
            }));

            const selectMenuTextColor = new MessageSelectMenu()
                .setCustomId('selectTextColor')
                .setPlaceholder('Select a text color')
                .addOptions(textColorOptions);

            await interaction?.update({
                content: 'Select text color:',
                embeds: [],
                components: [new MessageActionRow().addComponents(selectMenuTextColor)]
            });
        } else if (interaction.customId === 'selectTextColor') {
            const userData = userInputs.get(interaction?.user.id);
            const textColor = interaction?.values[0];
            userInputs.set(interaction?.user.id, { ...userData, textColor });

            const fontOptions = [
                { label: 'Arial', value: 'Arial' },
                { label: 'Verdana', value: 'Verdana' },
                { label: 'Times New Roman', value: 'Times New Roman' },
                { label: 'Courier New', value: 'Courier New' },
                { label: 'Georgia', value: 'Georgia' },
                { label: 'Palatino', value: 'Palatino' },
                { label: 'Garamond', value: 'Garamond' },
                { label: 'Bookman', value: 'Bookman' },
                { label: 'Comic Sans MS', value: 'Comic Sans MS' },
                { label: 'Trebuchet MS', value: 'Trebuchet MS' },
                { label: 'Arial Black', value: 'Arial Black' },
                { label: 'Impact', value: 'Impact' },
                { label: 'Lucida Sans', value: 'Lucida Sans' },
                { label: 'Tahoma', value: 'Tahoma' },
                { label: 'Geneva', value: 'Geneva' },
            ];

            const selectMenuFontType = new MessageSelectMenu()
                .setCustomId('selectFontType')
                .setPlaceholder('Select a font type')
                .addOptions(fontOptions);

            await interaction?.update({
                content: 'Select font type:',
                embeds: [],
                components: [new MessageActionRow().addComponents(selectMenuFontType)]
            });
        } else if (interaction.customId === 'selectFontType') {
            const userData = userInputs.get(interaction?.user.id);
            const fontType = interaction?.values[0];
            
            // إضافة fontType للبيانات
            const finalData = { ...userData, fontType };
            userInputs.set(interaction?.user.id, finalData);

            await interaction?.deferUpdate();

            await createAndSendImage(interaction, finalData);
            userInputs.delete(interaction?.user.id);
        }
    }
});
// دالة إنشاء وإرسال صورة بانر مخصصة
async function createAndSendImage(interaction, data) {
    try {
        const { imageUrl, text, fontSize, textColor, fontType } = data;
        
        // التحقق من الرابط
        if (!imageUrl || !imageUrl.startsWith('http')) {
            return interaction?.followUp({ content: 'لم يتم تفعيل الامر من قبل المالك', ephemeral: true });
        }
        
        const canvas = createCanvas(600, 240);
        const ctx = canvas.getContext('2d');

        // تحميل الصورة من الرابط
        const image = await loadImageFromUrl(imageUrl);

        // رسم الصورة على الـ Canvas
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

        // إعداد وكتابة النص
        ctx.fillStyle = textColor || 'white';
        ctx.font = `${fontSize || 30}px ${fontType || 'Arial'}`;
        ctx.textAlign = 'center';
        ctx.fillText(text || '', canvas.width / 2, canvas.height / 2 + parseInt(fontSize || 30) / 4);

        // إرسال الصورة
        const attachment = new Discord.MessageAttachment(canvas.toBuffer(), 'banner.png');
        await interaction?.followUp({ files: [attachment], ephemeral: true });
    } catch (err) {
        console.error('خطأ في إنشاء البانر:', err);
        await interaction?.followUp({ 
            content: '❌ فشل في إنشاء البانر\nتأكد من:\n• الرابط صحيح ومباشر للصورة\n• الصورة بصيغة PNG أو JPG', 
            ephemeral: true 
        });
    }
}

// دالة لتحويل أسماء الألوان للعربية
function getArabicColorName(color) {
    switch (color) {
        case 'black': return 'أسود';
        case 'white': return 'أبيض';
        case 'purple': return 'بنفسجي';
        case 'blue': return 'أزرق';
        case 'red': return 'أحمر';
        case 'brown': return 'بني';
        default: return color;
    }
}


// استيراد مكتبة استخراج الألوان من الصور
const getImageColors = require('get-image-colors');

// مكتبة Canvas أخرى للرسم
const ca = require("canvas-constructor/cairo");

// معالج Modal لعرض الأفتار والبانر
client.on("interactionCreate", async i => {
    if (i.isModalSubmit()) {
        if (i.customId === "av-banner") {
            try {
                await i.deferReply({ ephemeral: true })
                const id = i.fields.getTextInputValue("user_id").trim();
                
                // التحقق من صحة الآيدي
                if (!id || !/^\d{17,19}$/.test(id)) {
                    return i.editReply({ content: `❌ الآيدي غير صحيح! يجب أن يكون من 17-19 رقم` });
                }
                
                let user;
                try {
                    user = await i.client.users.fetch(id);
                } catch (error) {
                    console.error('خطأ في جلب المستخدم:', error);
                    return i.editReply({ content: `❌ لم أتمكن من العثور على هذا المستخدم` });
                }
                
                if (!user) return i.editReply({ content: `❌ هذا العضو غير موجود` });
                
                let response;
                try {
                    response = await fetch(`https://discord.com/api/v9/users/${user.id}`, {
                        headers: {
                            Authorization: `Bot ${client.token}`
                        }
                    });

                    if (!response.ok) {
                        console.error('Discord API Error:', response.status, response.statusText);
                        return i.editReply({ content: `❌ فشل في جلب بيانات المستخدم من Discord` });
                    }
                } catch (error) {
                    console.error('خطأ في الاتصال بـ Discord API:', error);
                    return i.editReply({ content: `❌ حدث خطأ في الاتصال بـ Discord` });
                }

                const userData = await response.json();
                const avatarURL = userData.avatar ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png` : `https://cdn.discordapp.com/embed/avatars/${userData.discriminator % 5}.png`;
                const bannerURL = userData.banner ? `https://cdn.discordapp.com/banners/${userData.id}/${userData.banner}.png?size=1024` : null;

                let colors, dominantColor;
                try {
                    colors = await getImageColors(cleanImageUrl(avatarURL));
                    dominantColor = colors[0].hex();
                } catch (colorError) {
                    console.error('خطأ في استخراج الألوان:', colorError);
                    dominantColor = '#5865f2'; // لون افتراضي
                }

                const fetchedUserr = await client.users.fetch(user.id);
                const avatarbotn = fetchedUserr.displayAvatarURL({ dynamic: true, format: 'png', size: 512 });

                const fetchedUser = await client.users.fetch(user.id, { force: true });
                const bannerbotn = fetchedUser.banner ? fetchedUser.bannerURL({ dynamic: true, size: 1024 }) : null;

                let avatarImage = null;
                let avatarAvailable = true;

                try {
                    avatarImage = await ca.loadImage(cleanImageUrl(avatarURL));
                } catch (avatarError) {
                    console.error('خطأ في تحميل الأفتار:', avatarError);
                    avatarAvailable = false;
                }

                const canvas = new ca.Canvas(350, 220);
                canvas.setColor(dominantColor).printRectangle(0, 0, 350, 220);

                if (bannerURL) {
                    try {
                        const bannerImage = await ca.loadImage(cleanImageUrl(bannerURL));
                        canvas.printImage(bannerImage, 0, 0, 350, 110);
                    } catch (bannerError) {
                        console.error('خطأ في تحميل البانر:', bannerError);
                        canvas.setColor('#909090').printRectangle(0, 0, 350, 110);
                    }
                } else {
                    canvas.setColor('#909090').printRectangle(0, 0, 350, 110);
                }

                if (avatarAvailable && avatarImage) {
                    canvas.setColor(dominantColor).printCircle(70, 110, 53);
                    canvas.printCircularImage(avatarImage, 70, 110, 45);
                }

                canvas.setColor('#ffffff').setTextSize(19).setTextAlign('left').printText(`@${userData.username}`, 15, 178);

                const attachment = new Discord.MessageAttachment(canvas.toBuffer(), 'avatar.png');
                const actionRow = new MessageActionRow()

                const bannerButton = new MessageButton()
                    .setLabel('Banner')
                    .setStyle(2)
                    .setCustomId('show_banner');

                const avatarButton = new MessageButton()
                    .setLabel('Avatar')
                    .setStyle(2)
                    .setCustomId('show_avatar');




                // إضافة الأزرار بدون زر البنر إذا لم يكن هناك بنر للسيرفر
                actionRow.addComponents(bannerButton, avatarButton);



                const replyMessage = await i.editReply({ files: [attachment], components: [actionRow], ephemeral: true });

                const filter = (interaction) => interaction.user.id === interaction.user.id;
                const collector = replyMessage.createMessageComponentCollector({ filter, time: 15000 });

                let collectedInteraction; // Define outside the scope of collector.on

                collector.on('collect', async (interaction) => {
                    if (interaction.isButton()) {
                        const buttonId = interaction.customId;
                        if (buttonId === 'show_banner') {
                            if (bannerURL) {
                                await interaction.reply({ files: [bannerURL], ephemeral: true });
                            } else {
                                await interaction.reply({ content: 'لا يمُلك بنر. ❌', ephemeral: true });
                            }
                        } else if (buttonId === 'show_avatar') {
                            if (avatarbotn) {
                                await interaction.reply({ files: [avatarbotn], ephemeral: true });
                            } else {
                                await interaction.reply({ content: 'لا يمُلك افتار. ❌', ephemeral: true });
                            }
                        }

                    }

                    // Capture interacion for later use
                    collectedInteraction = interaction;
                });

                collector.on('end', () => {
                    if (collectedInteraction) {
                        collectedInteraction.message.edit({ components: [] }); // Remove buttons after collector ends
                    } else {
                        console.error('No interaction object captured during collection.');
                    }
                });
            } catch (error) {
                console.error('خطأ عام في معالج av-banner:', error);
                const errorMessage = `❌ حدث خطأ غير متوقع: ${error.message}`;
                if (i.deferred || i.replied) {
                    await i.editReply({ content: errorMessage }).catch(console.error);
                } else {
                    await i.reply({ content: errorMessage, ephemeral: true }).catch(console.error);
                }
            }
        }
    }
});


// معالج Modal لتحويل الصورة للأبيض والأسود (Greyscale)
client.on("interactionCreate", async i => {
    if (!i.isModalSubmit()) return
    if (i.customId === "wb_modal") {
        const url = i.fields.getTextInputValue("imgurl")
        
        // التحقق من صحة الرابط
        if (!url || !url.startsWith('http')) {
            return i.reply({ ephemeral: true, content: `لم يتم تفعيل الامر من قبل المالك` });
        }
        
        await i.reply({ ephemeral: true, content: `⏳ يرجى الانتظار...` })
        
        try {
            const img = await loadImageFromUrl(url);
            
            const canvas = createCanvas(img.width, img.height);
            const ctx = canvas.getContext('2d');
            
            ctx.drawImage(img, 0, 0);
            
            // تطبيق تأثير greyscale
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const data = imageData.data;
            
            for (let j = 0; j < data.length; j += 4) {
                const avg = (data[j] + data[j + 1] + data[j + 2]) / 3;
                data[j] = avg;     // R
                data[j + 1] = avg; // G
                data[j + 2] = avg; // B
            }
            
            ctx.putImageData(imageData, 0, 0);
            
            await i.editReply({ 
                files: [{ attachment: canvas.toBuffer(), name: "greyscale.png" }], 
                content: `✅ تم تحويل الصورة للأبيض والأسود` 
            });
        } catch (err) {
            console.error('خطأ في greyscale:', err);
            await i.editReply({ 
                content: `❌ فشل في معالجة الصورة.\nتأكد من:\n• الرابط صحيح\n• الصورة بصيغة PNG أو JPG\n• الرابط مباشر للصورة` 
            });
        }
    }
})


/* ── KSHK SOURCE MARK ─────────────────────────────────────────────
 * KSHK Store · discord.gg/kshk · © 2026
 * Protected component of the KSHK Control Suite.
 * ───────────────────────────────────────────────────────────────── */


// استيراد مكتبات HTTP و Form Data
const FormData = require('form-data');
const { brotliDecompress } = require("zlib");

/*
 * [KSHK / CONTROL SUITE]
 * Source ownership: KSHK Store
 * Community: discord.gg/kshk
 * © 2026 KSHK Store — protected source
 */


// معالج Modal لإزالة خلفية الصورة باستخدام remove.bg API
client.on("interactionCreate", async i => {
    if (i.isModalSubmit()) {
        if (i.customId === "bg_modal") {
            await i.reply({ content: `wait some time`, ephemeral: true })
            const url = cleanImageUrl(i.fields.getTextInputValue('bg_urll'))
            const formData = new FormData();
            formData.append('size', 'auto');
            formData.append('image_url', `${url}`);

            axios({
                method: 'post',
                url: 'https://api.remove.bg/v1.0/removebg',
                data: formData,
                responseType: 'arraybuffer',
                headers: {
                    ...formData.getHeaders(),
                    'X-Api-Key': config.removeBgKey,
                },
                encoding: null
            })
                .then((response) => {
                    if (response.status != 200) return console.error('Error:', response.status, response.statusText);
                    const img = Buffer.from(response.data)
                    const attachment = new Discord.MessageAttachment(img, "dsd.png")
                    i.editReply({ files: [attachment], content: `This is Your Image` })
                })
                .catch((error) => {
                    return console.error('Request failed:', error);
                });
        }
    }
})


// معالجة أخطاء البوت والعمليات لمنع التوقف المفاجئ
client.on('error', error => console.log(error));
client.on('warn', info => console.log(info));
process.on('unhandledRejection', (reason, p) => {
    console.log(reason.stack ? reason.stack : reason)
});
process.on("uncaughtException", (err, origin) => {
    console.log(err.stack ? err.stack : err)
})
process.on('uncaughtExceptionMonitor', (err, origin) => {
    console.log(err.stack ? err.stack : err)
});
client.on("disconnecting", () => console.log("Bot is disconnecting...", "warn"))
    .on("reconnecting", () => console.log("Bot reconnecting...", "log"))
    .on("error", (e) => console.log(e, "error"))
    .on("warn", (info) => console.log(info, "warn"));

// تجاهل الأخطاء غير المعالجة لمنع توقف البوت
process.on("unhandledRejection", (reason, promise) => { return })
process.on("uncaughtException", (err, origin) => { return })
process.on('uncaughtExceptionMonitor', (err, origin) => { return });
process.on('multipleResolves', (type, promise, reason) => { return })

// ====== AI MENU HANDLERS ======
// تخزين التكتات النشطة
const activeAITickets = new Map();

// ====== EFFECTS MENU HANDLER ======
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isSelectMenu()) return;
    if (interaction.customId !== 'effects_menu') return;

    const value = interaction.values[0];

    // Function لإعادة تعيين القوائم
    async function resetMenus() {
        try {
            await interaction.message.edit({ components: interaction.message.components });
        } catch (e) {}
    }

    // Avatar Effects - عرض قوائم التأثيرات
    if (value === 'effects_avatar' || value === 'effects_decorations' || value === 'effects_flags') {
        await interaction.deferReply({ ephemeral: true });
        
        try {
            const effectMenus = createEffectSelectMenus();
            
            // فلترة حسب الاختيار
            let filteredMenus = effectMenus;
            if (value === 'effects_decorations') {
                filteredMenus = effectMenus.filter(menu => 
                    menu.components[0].customId.includes('decorations')
                );
            } else if (value === 'effects_flags') {
                filteredMenus = effectMenus.filter(menu => 
                    menu.components[0].customId.includes('flags')
                );
            }

            const embed = new Discord.MessageEmbed()
                .setColor('#FF0000')
                .setTitle('زين صورتك')
                .setDescription('اختر التأثير اللي يعجبك وراح يتطبق على صورتك')
                .setFooter({ text: 'اختر من القائمة تحت' });

            setTimeout(resetMenus, 500);
            await interaction.editReply({
                embeds: [embed],
                components: filteredMenus.slice(0, 5) // حد 5 صفوف
            });
        } catch (error) {
            console.error('خطأ في عرض التأثيرات:', error);
            setTimeout(resetMenus, 500);
            await interaction.editReply({
                content: 'لم يتم تفعيل الامر من قبل المالك'
            });
        }
    }

    // Effects Help
    else if (value === 'effects_help') {
        const helpText = `مساعدة التأثيرات | اختر تأثير من القائمة وراح يتطبق على صورتك ويطلع لك GIF متحرك`;

        setTimeout(resetMenus, 500);
        return interaction.reply({ content: helpText, ephemeral: true });
    }
});

// معالج اختيار التأثير من القوائم الفرعية
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isSelectMenu()) return;
    if (!interaction.customId.startsWith('effect_select_')) return;

    const effectId = interaction.values[0];
    
    await interaction.deferReply({ ephemeral: true });

    try {
        const avatarUrl = interaction.user.displayAvatarURL({ size: 256, format: 'png' });
        
        await interaction.editReply({
            content: `انتظر شوي جاري انشاء الصورة...`
        });

        const gifBuffer = await createEffectGif(avatarUrl, effectId);

        if (!gifBuffer) {
            await interaction.editReply({
                content: 'لم يتم تفعيل الامر من قبل المالك'
            });
            return;
        }

        const attachment = new Discord.MessageAttachment(gifBuffer, 'avatar_effect.gif');
        await interaction.editReply({
            content: `تفضل صورتك مع التأثير`,
            files: [attachment]
        });

    } catch (error) {
        console.error('خطأ في تطبيق التأثير:', error);
        await interaction.editReply({
            content: 'لم يتم تفعيل الامر من قبل المالك'
        });
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isSelectMenu()) return;
    if (interaction.customId !== 'ai_menu') return;

    const value = interaction.values[0];

    // Function لإعادة تعيين القوائم
    async function resetMenus() {
        try {
            await interaction.message.edit({ components: interaction.message.components });
        } catch (e) {}
    }

    // AI Chat - فتح تكت
    if (value === 'ai_chat') {
        // التحقق من وجود تكت مفتوح
        if (activeAITickets.has(interaction.user.id)) {
            const ticketId = activeAITickets.get(interaction.user.id);
            setTimeout(resetMenus, 500);
            return interaction.reply({
                content: `✅ لديك تكت مفتوح بالفعل: <#${ticketId}>`,
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            // الحصول على الكاتيجوري من config
            const ticketCategoryId = config.aiTicketCategory || null;
            
            // إنشاء قناة خاصة (تكت)
            const ticketChannel = await interaction.guild.channels.create(`ai-${interaction.user.username}`, {
                type: 'GUILD_TEXT',
                parent: ticketCategoryId, // الكاتيجوري من config
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: ['VIEW_CHANNEL']
                    },
                    {
                        id: interaction.user.id,
                        allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                    },
                    {
                        id: client.user.id,
                        allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                    }
                ]
            });

/*
 * [KSHK / CONTROL SUITE]
 * Source ownership: KSHK Store
 * Community: discord.gg/kshk
 * © 2026 KSHK Store — protected source
 */


            // حفظ التكت
            activeAITickets.set(interaction.user.id, ticketChannel.id);

            // زر إغلاق التكت
            const closeButton = new MessageActionRow().addComponents(
                new MessageButton()
                    .setCustomId('close_ai_ticket')
                    .setLabel('إغلاق التكت')
                    .setStyle('DANGER')
                    .setEmoji('🔒')
            );

            await ticketChannel.send({
                content: `👋 مرحباً ${interaction.user}!\n\n🤖 أنا مساعدك الذكي بالذكاء الاصطناعي\n\n✨ يمكنني مساعدتك في:\n• الإجابة على أسئلتك بالعربية أو الإنجليزية\n• كتابة وشرح الأكواد البرمجية\n• حل المشاكل والمساعدة في المشاريع\n• الترجمة والكتابة الإبداعية\n• أي شيء آخر تحتاجه!\n\n💬 ابدأ المحادثة:\nاكتب رسالتك هنا وسأرد عليك فوراً\n\n🔒 للإغلاق:\nاستخدم الزر أدناه عند الانتهاء`,
                components: [closeButton]
            });

            setTimeout(resetMenus, 500);
            await interaction.editReply({
                content: `✅ تم فتح تكت AI الخاص بك: ${ticketChannel}`
            });

        } catch (error) {
            console.error('خطأ في إنشاء تكت AI:', error);
            setTimeout(resetMenus, 500);
            await interaction.editReply({
                content: '❌ حدث خطأ في إنشاء التكت'
            });
        }
    }

    // AI Translate
    else if (value === 'ai_translate') {
        const modal = new Discord.Modal()
            .setCustomId('ai_translate_modal')
            .setTitle("ترجمة نص");

        const textInput = new Discord.TextInputComponent()
            .setCustomId("translate_text")
            .setLabel("النص المراد ترجمته")
            .setStyle('PARAGRAPH')
            .setRequired(true);

        const langInput = new Discord.TextInputComponent()
            .setCustomId("translate_lang")
            .setLabel("اللغة المستهدفة (مثال: en, ar, fr)")
            .setStyle('SHORT')
            .setPlaceholder('ar')
            .setRequired(true);

        modal.addComponents(
            new Discord.MessageActionRow().addComponents(textInput),
            new Discord.MessageActionRow().addComponents(langInput)
        );
        await interaction.showModal(modal);
        setTimeout(resetMenus, 500);
    }

    // AI Help
    else if (value === 'ai_help') {
        const helpText = `🤖 مساعدة AI\n\n` +
            `💬 Chat: فتح تكت خاص للمحادثة مع AI\n` +
            `• اطرح أي سؤال\n` +
            `• اطلب كتابة كود\n` +
            `• احصل على شروحات\n\n` +
            `🎨 Image: إنشاء صورة بالذكاء الاصطناعي\n` +
            `• صف الصورة بالتفصيل\n` +
            `• استخدم اللغة الإنجليزية للنتائج الأفضل\n\n` +
            `🌐 Translate: ترجمة نصوص\n` +
            `• ترجمة من وإلى أي لغة\n` +
            `• دعم جميع اللغات\n\n` +
            `⚠️ ملاحظة: يتطلب مفتاح OpenAI API صالح`;

        setTimeout(resetMenus, 500);
        return interaction.reply({ content: helpText, ephemeral: true });
    }
});

// معالج إغلاق تكت AI
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId !== 'close_ai_ticket') return;

    await interaction.deferReply({ ephemeral: true });

    try {
        // حذف من القائمة
        for (const [userId, channelId] of activeAITickets.entries()) {
            if (channelId === interaction.channel.id) {
                activeAITickets.delete(userId);
                break;
            }
        }

        await interaction.editReply('✅ سيتم إغلاق التكت خلال 5 ثواني...');
        
        setTimeout(async () => {
            try {
                await interaction.channel.delete();
            } catch (e) {
                console.error('خطأ في حذف التكت:', e);
            }
        }, 5000);

    } catch (error) {
        console.error('خطأ في إغلاق التكت:', error);
        await interaction.editReply('❌ حدث خطأ في إغلاق التكت');
    }
});

// معالج رسائل AI في التكتات
client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    if (!message.channel.name || !message.channel.name.startsWith('ai-')) return;

// KSHK Store • Protected Source • discord.gg/kshk • © 2026


    // التحقق من أن القناة تكت AI نشط
    if (!activeAITickets.has(message.author.id)) return;

    // الحصول على API Key من السيرفر
    const guildAPIKey = getGuildAPIKey(message.guild.id);
    
    if (!guildAPIKey) {
        return message.reply('❌ مفتاح API غير مُعد لهذا السيرفر\n\nللمدير:\nيجب إضافة API Key في ملف `AI/config.json`');
    }

    try {
        await message.channel.sendTyping();

        // إنشاء OpenAI client مع OpenRouter
        const { OpenAI } = require("openai");
        const guildOpenAI = new OpenAI({ 
            apiKey: guildAPIKey,
            baseURL: "https://openrouter.ai/api/v1"
        });

        const response = await guildOpenAI.chat.completions.create({
            model: "openai/gpt-3.5-turbo",
            messages: [
                {
                    role: "system",
                    content: "أنت مساعد ذكي ومفيد باللغة العربية. أجب بشكل واضح ومختصر باللغة العربية. إذا سُئلت بلغة أخرى، أجب بنفس اللغة."
                },
                {
                    role: "user",
                    content: message.content
                }
            ],
            max_tokens: 1000,
            temperature: 0.7
        });

        const aiReply = response.choices[0].message.content;
        
        // تقسيم الرد إذا كان طويل
        if (aiReply.length > 2000) {
            const chunks = aiReply.match(/.{1,2000}/g);
            for (const chunk of chunks) {
                await message.reply(chunk);
            }
        } else {
            await message.reply(aiReply);
        }

    } catch (error) {
        console.error('خطأ في AI:', error);
        let errorMsg = '❌ حدث خطأ في الاتصال بـ AI';
        
        if (error.message && error.message.includes('API key')) {
            errorMsg = '❌ مفتاح OpenAI API غير صحيح';
        } else if (error.message && error.message.includes('rate limit')) {
            errorMsg = '❌ تم تجاوز الحد المسموح. حاول لاحقاً';
        } else if (error.message && error.message.includes('billing')) {
            errorMsg = '❌ حساب OpenAI يحتاج رصيد';
        }
        
        await message.reply(errorMsg);
    }
});

/* ── KSHK SOURCE MARK ─────────────────────────────────────────────
 * KSHK Store · discord.gg/kshk · © 2026
 * Protected component of the KSHK Control Suite.
 * ───────────────────────────────────────────────────────────────── */


// معالج modal الترجمة
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId !== 'ai_translate_modal') return;

    await interaction.deferReply({ ephemeral: true });

    try {
        const text = interaction.fields.getTextInputValue('translate_text');
        const targetLang = interaction.fields.getTextInputValue('translate_lang');

        const result = await translate(text, null, targetLang);
        
        await interaction.editReply({
            content: `🌐 الترجمة:\n\n${result.translation}`
        });

    } catch (error) {
        console.error('خطأ في الترجمة:', error);
        await interaction.editReply({
            content: '❌ حدث خطأ في الترجمة'
        });
    }
});

// تسجيل دخول البوت الرئيسي
client.login(config.token).then(() => {
    console.log('Main Bot logged in successfully');
}).catch(error => {
    console.error('Main Bot login failed:', error);
});

// تسجيل دخول السيلف بوت
if (config.users && config.users.trim() !== "") {
    clients.login(config.users).then(() => {
        console.log('✅ Self Bot logged in successfully');
    }).catch(error => {
        console.error('❌ Self Bot login failed:', error.message);
        console.log('🔍 كود الخطأ:', error.code);
        
        // التحقق من نوع الخطأ وعرض رسالة مناسبة
        if (error.message.includes('Invalid') || error.code === 'TOKEN_INVALID') {
            console.log('❌ التوكن غير صحيح. تأكد من صحة توكن السيلف بوت');
            console.log('💡 تأكد من أن التوكن يبدأ بـ mfa أو أرقام');
        } else if (error.message.includes('Unauthorized') || error.code === 'DISALLOWED_INTENTS') {
            console.log('❌ غير مصرح. مشكلة في الـ intents أو التوكن منتهي الصلاحية');
        } else {
            console.log('خطأ في تسجيل الدخول:', error.message);
        }
    });
} else {
}

