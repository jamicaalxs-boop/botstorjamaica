/*
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║                  JAMAICA STORE  /  discord.gg/NWXvGhSMA                     ║
║                                                                      ║
║                     © JAMAICA Store — All Rights Reserved              ║
║                                                                      ║
║              This project is protected by JAMAICA Store.               ║
║              Do not remove or modify this copyright notice.         ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
*/
const fs = require('fs');
const path = require('path');


/* ╔══════════════════════════════════════════════════════════════════╗
 * ║                 JAMAICA STORE / discord.gg/NWXvGhSMA                    ║
 * ║                       © JAMAICA Store                               ║
 * ╚══════════════════════════════════════════════════════════════════╝ */
const CONFIG_FILE = path.join(__dirname, '..', 'config.json');

function loadConfig() {
    if (!fs.existsSync(CONFIG_FILE)) {
        throw new Error(`${CONFIG_FILE} not found. Please create it.`);
    }

/* ╔══════════════════════════════════════════════════════════════════╗
 * ║                 JAMAICA STORE / discord.gg/NWXvGhSMA                    ║
 * ║                       © JAMAICA Store                               ║
 * ╚══════════════════════════════════════════════════════════════════╝ */
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));

/* ╔══════════════════════════════════════════════════════════════════╗
 * ║                 JAMAICA STORE / ddiscord.gg/NWXvGhSMA                    ║
 * ║                       © JAMAICA Store                               ║
 * ╚══════════════════════════════════════════════════════════════════╝ */
}

const config = loadConfig();

module.exports = { config };
