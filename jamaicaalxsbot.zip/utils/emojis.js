/*
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║                  JAMAICA STORE  /  discord.gg/NWXvGhSMA                     ║
║                                                                      ║
║                     © JAMAICA Store — All Rights Reserved              ║
║                                                                      ║
║              This project is protected by JAMAICA Store.               ║
║              Do not remove or modify this copyright notice.         ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
*/
// Central emoji mapping for bot messages and UI labels.


/* ╔══════════════════════════════════════════════════════════════════╗
 * ║                 JAMAICA STORE / discord.gg/NWXvGhSMA                    ║
 * ║                       © JAMAICA Store                               ║
 * ╚══════════════════════════════════════════════════════════════════╝ */
const EMOJIES = {
    success: '<a:success:1488644502867411154>',
    error: '<a:wrong:1498276365101830254>',

/* ╔══════════════════════════════════════════════════════════════════╗
 * ║                 JAMAICA STORE / discord.gg/NWXvGhSMA                    ║
 * ║                       © JAMAICA Store                               ║
 * ╚══════════════════════════════════════════════════════════════════╝ */
    stop: '<a:close:1475299132804567181>',
    refresh: '<:refresh:1498276670140973096>',
    quest: '<:Target:1488641286851399881>',
    rocket: '<a:Rocket:1498277075671453809>',
    orbs: '<:orbs:1488640810881908736>',
    quest_badge: '<:quest_completed:1498275316194611272>',
};


/* ╔══════════════════════════════════════════════════════════════════╗
 * ║                 JAMAICA STORE / discord.gg/NWXvGhSMA                    ║
 * ║                       © JAMAICA Store                               ║
 * ╚══════════════════════════════════════════════════════════════════╝ */
module.exports = { EMOJIES };
